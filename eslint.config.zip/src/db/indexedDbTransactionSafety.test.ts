﻿import { test } from 'node:test';
import assert from 'node:assert/strict';
import 'fake-indexeddb/auto';

function openTestDatabase(name: string): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(name, 1);

    request.onupgradeneeded = () => {
      request.result.createObjectStore('records', { keyPath: 'id' });
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function readRecord(db: IDBDatabase, id: string): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction('records', 'readonly');
    const request = tx.objectStore('records').get(id);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

test('IndexedDB transaction safety: committed writes persist', async () => {
  const db = await openTestDatabase('smartmind-transaction-commit-test');

  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('records', 'readwrite');
      tx.objectStore('records').put({ id: 'keep-1', value: 'committed' });
      tx.oncomplete = () => resolve();
      tx.onabort = () => reject(tx.error ?? new Error('Transaction aborted'));
      tx.onerror = () => reject(tx.error ?? new Error('Transaction failed'));
    });

    assert.deepEqual(await readRecord(db, 'keep-1'), {
      id: 'keep-1',
      value: 'committed',
    });
  } finally {
    db.close();
    indexedDB.deleteDatabase('smartmind-transaction-commit-test');
  }
});

test('IndexedDB transaction safety: aborted writes do not persist', async () => {
  const db = await openTestDatabase('smartmind-transaction-abort-test');

  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('records', 'readwrite');
      tx.objectStore('records').put({ id: 'should-not-exist', value: 'temporary' });

      tx.oncomplete = () => reject(new Error('Expected transaction to abort'));
      tx.onabort = () => resolve();
      tx.onerror = () => {
        // The abort event confirms the transaction did not commit.
      };

      tx.abort();
    });

    assert.equal(await readRecord(db, 'should-not-exist'), undefined);
  } finally {
    db.close();
    indexedDB.deleteDatabase('smartmind-transaction-abort-test');
  }
});
