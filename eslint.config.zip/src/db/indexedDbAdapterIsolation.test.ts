﻿import { test } from 'node:test';
import assert from 'node:assert/strict';
import 'fake-indexeddb/auto';

// Provide the browser globals that the adapter expects in Node tests.
Object.defineProperty(globalThis, 'window', {
  configurable: true,
  value: globalThis,
});

import { IndexedDbDatabaseAdapter } from './adapters/indexedDbAdapter';

test('adapter opens a dedicated test database, not the production database', async () => {
  const testDatabaseName = 'smartmind-isolated-adapter-test';
  const adapter = new IndexedDbDatabaseAdapter(testDatabaseName);

  try {
    await adapter.initialize();

    assert.equal(adapter.adapterType, 'indexeddb-browser-dev');

    const database = indexedDB.open(testDatabaseName);
    const openedDb = await new Promise<IDBDatabase>((resolve, reject) => {
      database.onsuccess = () => resolve(database.result);
      database.onerror = () => reject(database.error);
    });

    try {
      assert.ok(openedDb.objectStoreNames.contains('sales'));
      assert.ok(openedDb.objectStoreNames.contains('sync_queue'));
      assert.ok(openedDb.objectStoreNames.contains('audit_events'));
      assert.notEqual(testDatabaseName, 'smartmind_pos_local_db');
    } finally {
      openedDb.close();
    }
  } finally {
    await adapter.close();

    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.deleteDatabase(testDatabaseName);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('Test database deletion was blocked'));
    });
  }
});

