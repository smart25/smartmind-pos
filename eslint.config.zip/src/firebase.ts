/**
 * SmartMind POS — Phase 6: Firebase Client Initialization & Error Handling
 *
 * Uses provisioned firebase-applet-config.json with environment variable overrides.
 * Never embeds Firebase Admin SDK credentials or private service-account keys.
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  Auth,
} from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  setLogLevel,
  doc,
  getDocFromServer,
  Firestore,
} from 'firebase/firestore';
import {
  getFunctions,
  httpsCallable,
  Functions,
  HttpsCallable,
} from 'firebase/functions';
import appletConfig from '../firebase-applet-config.json';
import type {
  InviteAuthorizedStaffRequest,
  ProvisionBusinessRequest,
  ProvisionBusinessResponse,
  SetTenantStatusRequest,
  SyncOperationPayload,
  SyncOperationResponse,
} from '../functions/src/index';

export interface InviteAuthorizedStaffResponse {
  status: 'created';
  isIdempotentReplay?: boolean;
  staffUser: Record<string, any>;
}

export interface SetTenantStatusResponse {
  businessId: string;
  status: 'active' | 'suspended';
  updatedAt: string;
  auditEventId: string;
  subscriptionEventId: string;
}

export type {
  InviteAuthorizedStaffRequest,
  ProvisionBusinessRequest,
  ProvisionBusinessResponse,
  SetTenantStatusRequest,
  SyncOperationPayload,
  SyncOperationResponse,
};
export type SyncOperationRequest = SyncOperationPayload;

const env: Record<string, string | undefined> =
  typeof import.meta !== 'undefined' && (import.meta as any).env
    ? (import.meta as any).env
    : typeof process !== 'undefined' && process.env
    ? process.env
    : {};

export const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || appletConfig.apiKey,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || appletConfig.authDomain,
  projectId: env.VITE_FIREBASE_PROJECT_ID || appletConfig.projectId,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || appletConfig.storageBucket,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || appletConfig.messagingSenderId,
  appId: env.VITE_FIREBASE_APP_ID || appletConfig.appId,
  firestoreDatabaseId:
    env.VITE_FIREBASE_FIRESTORE_DATABASE_ID || appletConfig.firestoreDatabaseId,
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey !== 'YOUR_FIREBASE_API_KEY'
);

export function getFirebaseConfigDiagnostics() {
  const requiredEnvKeys = [
    'VITE_FIREBASE_API_KEY',
    'VITE_FIREBASE_AUTH_DOMAIN',
    'VITE_FIREBASE_PROJECT_ID',
    'VITE_FIREBASE_STORAGE_BUCKET',
    'VITE_FIREBASE_MESSAGING_SENDER_ID',
    'VITE_FIREBASE_APP_ID',
    'VITE_FIREBASE_FIRESTORE_DATABASE_ID',
  ] as const;

  const envPresence: Record<string, boolean> = {};
  for (const key of requiredEnvKeys) {
    envPresence[key] = Boolean(env[key] && String(env[key]).trim().length > 0);
  }

  return {
    isFirebaseConfigured,
    projectId: firebaseConfig.projectId,
    authDomain: firebaseConfig.authDomain,
    firestoreDatabaseId: firebaseConfig.firestoreDatabaseId,
    storageBucket: firebaseConfig.storageBucket,
    hasApiKey: Boolean(firebaseConfig.apiKey && firebaseConfig.apiKey.length > 10),
    hasAppId: Boolean(firebaseConfig.appId && firebaseConfig.appId.length > 10),
    hasMessagingSenderId: Boolean(firebaseConfig.messagingSenderId),
    envPresence,
  };
}

export const app: FirebaseApp =
  getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Prevent internal @firebase/firestore WebChannel transport retries from emitting noisy
// console.error logs when the POS operates in offline-first mode or behind iframe proxies.
try {
  setLogLevel('silent');
} catch {
  // Ignore if unsupported in test environment
}

function createFirestoreInstance(): Firestore {
  try {
    return initializeFirestore(
      app,
      {
        experimentalAutoDetectLongPolling: true,
      },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}

export const db: Firestore = createFirestoreInstance();
export const auth: Auth = getAuth(app);
export const functions: Functions = getFunctions(app, 'us-central1');
export const googleProvider = new GoogleAuthProvider();

export const callProvisionBusinessAndPrimaryOwner: HttpsCallable<
  ProvisionBusinessRequest,
  ProvisionBusinessResponse
> = httpsCallable<ProvisionBusinessRequest, ProvisionBusinessResponse>(
  functions,
  'provisionBusinessAndPrimaryOwner'
);

export const callInviteAuthorizedStaff: HttpsCallable<
  InviteAuthorizedStaffRequest,
  InviteAuthorizedStaffResponse
> = httpsCallable<InviteAuthorizedStaffRequest, InviteAuthorizedStaffResponse>(
  functions,
  'inviteAuthorizedStaff'
);

export const callSetTenantStatus: HttpsCallable<
  SetTenantStatusRequest,
  SetTenantStatusResponse
> = httpsCallable<SetTenantStatusRequest, SetTenantStatusResponse>(
  functions,
  'setTenantStatus'
);

export const callSyncPosOperation: HttpsCallable<
  SyncOperationPayload,
  SyncOperationResponse
> = httpsCallable<SyncOperationPayload, SyncOperationResponse>(
  functions,
  'syncPosOperation'
);

export const callSyncShopOperation: HttpsCallable<
  SyncOperationPayload,
  SyncOperationResponse
> = httpsCallable<SyncOperationPayload, SyncOperationResponse>(
  functions,
  'syncShopOperation'
);

export {
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  firebaseSignOut,
  onAuthStateChanged,
  httpsCallable,
};

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  if (typeof window === 'undefined' || !isFirebaseConfigured) {
    return false;
  }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return false;
  }
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.warn('Firestore client is currently operating in offline mode.');
      return false;
    }
    // Permission denied on /test/connection confirms Firestore server is reachable
    return true;
  }
}

if (typeof window !== 'undefined' && isFirebaseConfigured) {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      testFirestoreConnection().catch(() => {});
    }
  });
}
