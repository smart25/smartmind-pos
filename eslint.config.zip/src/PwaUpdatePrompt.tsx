﻿import { useRegisterSW } from 'virtual:pwa-register/react';

export default function PwaUpdatePrompt() {
  const {
    needRefresh: [needRefresh, setNeedRefresh],
    offlineReady: [offlineReady, setOfflineReady],
    updateServiceWorker,
  } = useRegisterSW();

  if (!needRefresh && !offlineReady) return null;

  return (
    <div
      role="status"
      style={{
        position: 'fixed',
        right: 16,
        bottom: 16,
        zIndex: 99999,
        maxWidth: 360,
        padding: 16,
        borderRadius: 12,
        background: '#064e3b',
        color: '#ffffff',
        boxShadow: '0 8px 30px rgba(0,0,0,.25)',
      }}
    >
      <p style={{ margin: '0 0 12px' }}>
        {needRefresh
          ? 'A SmartMind POS update is ready. Save or finish active sales before updating.'
          : 'SmartMind POS is ready for offline app-shell access.'}
      </p>

      {needRefresh && (
        <button
          type="button"
          onClick={() => void updateServiceWorker(true)}
          style={{ marginRight: 8, padding: '8px 12px', cursor: 'pointer' }}
        >
          Update now
        </button>
      )}

      <button
        type="button"
        onClick={() => {
          setNeedRefresh(false);
          setOfflineReady(false);
        }}
        style={{ padding: '8px 12px', cursor: 'pointer' }}
      >
        Dismiss
      </button>
    </div>
  );
}
