export interface ElectronSqliteBridge {
  query<T = any>(sql: string, params?: any[]): Promise<T[]>;
  execute(sql: string, params?: any[]): Promise<{ changes: number; lastInsertRowid?: number | bigint }>;
  beginTransaction(): Promise<void>;
  commitTransaction(): Promise<void>;
  rollbackTransaction(): Promise<void>;
  getSchemaVersion(): Promise<number>;
  backupDatabase(destinationPath?: string): Promise<{ success: boolean; filePath: string }>;
}

export interface SmartmindDesktopInfo {
  isElectron: boolean;
  platform: string;
  arch: string;
  appVersion: string;
  electronVersion: string;
  chromeVersion: string;
  nodeVersion: string;
}

export interface SmartmindDesktopWindowControls {
  minimize: () => Promise<void>;
  maximize: () => Promise<void>;
  close: () => Promise<void>;
  isMaximized: () => Promise<boolean>;
}

export interface SmartmindDesktopApi {
  isElectron: boolean;
  platform: string;
  appVersion: string;
  getDesktopInfo: () => Promise<SmartmindDesktopInfo>;
  signInWithGoogle: () => Promise<{ idToken: string }>;
  minimize: () => Promise<void>;
  maximize: () => Promise<void>;
  close: () => Promise<void>;
  isMaximized: () => Promise<boolean>;
  sqlite?: ElectronSqliteBridge;
}

declare global {
  interface Window {
    smartmindDesktopApi?: SmartmindDesktopApi;
  }
}
