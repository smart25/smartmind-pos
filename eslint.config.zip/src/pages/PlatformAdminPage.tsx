import React, { useState, useMemo } from 'react';
import {
  Building2,
  Plus,
  Search,
  ShieldCheck,
  Store,
  UserCheck,
  Edit3,
  Eye,
  Power,
  AlertCircle,
  CheckCircle2,
  LogOut,
  X,
  Mail,
  Phone,
  MapPin,
  Lock,
  Users,
} from 'lucide-react';
import {
  Business,
  BusinessStatus,
  BusinessType,
  ConnectivitySnapshot,
  ConnectivityState,
  Shop,
  User,
  CustomRole,
} from '../types/pos';
import {
  CreateBusinessInput,
  CreateCustomRoleInput,
  getAdminPageBusinessOwners,
  getVisibleUsersForActor,
  validateBusinessRegistrationInput,
} from '../utils/posCalculations';
import { ConnectivityStatusControl } from '../components/layout/ConnectivityStatusControl';
import { DataEnvironmentMode } from '../services/liveFirestoreDataService';

interface PlatformAdminPageProps {
  currentUser: User;
  businesses: Business[];
  shops: Shop[];
  users: User[];
  customRoles?: CustomRole[];
  dataMode?: DataEnvironmentMode;
  firestoreDatabaseId?: string;
  connectivity: ConnectivitySnapshot;
  onChangeConnectivityState: (state: ConnectivityState) => void;
  onCreateBusiness: (input: CreateBusinessInput) => Business;
  onUpdateBusiness: (businessId: string, input: CreateBusinessInput) => void;
  onToggleBusinessStatus: (
    businessId: string,
    nextStatus: BusinessStatus
  ) => void | Promise<void>;
  onSwitchDemoUser: (userId: string) => void;
  onSignOut: () => void;
  onCreateCustomRole?: (input: CreateCustomRoleInput) => CustomRole;
  onUpdateCustomRole?: (roleId: string, input: CreateCustomRoleInput) => void;
  onDeleteCustomRole?: (roleId: string) => { success: boolean; error?: string };
}

const BUSINESS_TYPES: BusinessType[] = [
  'Supermarket & Grocery Chain',
  'Pharmacy & Healthcare Retail',
  'Department & General Retail',
  'Restaurant, Bakery & Hospitality',
  'Specialty & Convenience Stores',
];

export const PlatformAdminPage: React.FC<PlatformAdminPageProps> = ({
  currentUser,
  businesses,
  shops,
  users,
  customRoles = [],
  dataMode = 'live',
  firestoreDatabaseId = 'ai-studio-smartmindpos-3ebff8f1-fed5-4111-b7db-f027e942fbb4',
  connectivity,
  onChangeConnectivityState,
  onCreateBusiness,
  onUpdateBusiness,
  onToggleBusinessStatus,
  onSwitchDemoUser,
  onSignOut,
  onCreateCustomRole,
  onUpdateCustomRole,
  onDeleteCustomRole,
}) => {
  const isDemoMode = dataMode === 'demo';
  const draftStorageKey = 'smartmind_platform_admin_draft';
  const savedDraft = useMemo(() => {
    if (typeof window === 'undefined') return null;
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('reset') === '1') {
        window.sessionStorage.removeItem(draftStorageKey);
        window.localStorage.removeItem(draftStorageKey);
        return null;
      }
      const raw =
        window.sessionStorage.getItem(draftStorageKey) ||
        window.localStorage.getItem(draftStorageKey);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }, []);

  const [searchQuery, setSearchQuery] = useState<string>(
    savedDraft?.searchQuery ?? ''
  );
  const [statusFilter, setStatusFilter] = useState<'all' | BusinessStatus>(
    savedDraft?.statusFilter ?? 'all'
  );
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');
  const [userBusinessFilter, setUserBusinessFilter] = useState<string>('all');
  const [feedbackBanner, setFeedbackBanner] = useState<string | null>(null);

  // Create / Edit Business Modal State
  const [formOpen, setFormOpen] = useState<boolean>(
    savedDraft?.formOpen ?? false
  );
  const [editingBusiness, setEditingBusiness] = useState<Business | null>(
    () =>
      savedDraft?.editingBusinessId
        ? businesses.find((b) => b.id === savedDraft.editingBusinessId) ?? null
        : null
  );
  const [nameInput, setNameInput] = useState<string>(
    savedDraft?.nameInput ?? ''
  );
  const [typeInput, setTypeInput] = useState<BusinessType>(
    savedDraft?.typeInput ?? BUSINESS_TYPES[0]
  );
  const [contactEmailInput, setContactEmailInput] = useState<string>(
    savedDraft?.contactEmailInput ?? ''
  );
  const [phoneInput, setPhoneInput] = useState<string>(
    savedDraft?.phoneInput ?? ''
  );
  const [addressInput, setAddressInput] = useState<string>(
    savedDraft?.addressInput ?? ''
  );
  const [ownerNameInput, setOwnerNameInput] = useState<string>(
    savedDraft?.ownerNameInput ?? ''
  );
  const [ownerEmailInput, setOwnerEmailInput] = useState<string>(
    savedDraft?.ownerEmailInput ?? ''
  );
  const [ownerUidInput, setOwnerUidInput] = useState<string>(
    savedDraft?.ownerUidInput ?? ''
  );
  const [initialShopNameInput, setInitialShopNameInput] = useState<string>(
    savedDraft?.initialShopNameInput ?? ''
  );
  const [initialShopCategoryInput, setInitialShopCategoryInput] =
    useState<string>(savedDraft?.initialShopCategoryInput ?? 'Supermarket');
  const [initialShopCityInput, setInitialShopCityInput] = useState<string>(
    savedDraft?.initialShopCityInput ?? 'Lagos'
  );
  const [initialShopAddressInput, setInitialShopAddressInput] =
    useState<string>(savedDraft?.initialShopAddressInput ?? '');
  const [notesInput, setNotesInput] = useState<string>(
    savedDraft?.notesInput ?? ''
  );
  const [formError, setFormError] = useState<string | null>(null);

  // Inspect Business & Registered Shops Modal State
  const [inspectedBusinessId, setInspectedBusinessId] = useState<string | null>(
    savedDraft?.inspectedBusinessId ?? null
  );

  React.useEffect(() => {
    const serialized = JSON.stringify({
      searchQuery,
      statusFilter,
      formOpen,
      editingBusinessId: editingBusiness?.id ?? null,
      nameInput,
      typeInput,
      contactEmailInput,
      phoneInput,
      addressInput,
      ownerNameInput,
      ownerEmailInput,
      ownerUidInput,
      initialShopNameInput,
      initialShopCategoryInput,
      initialShopCityInput,
      initialShopAddressInput,
      notesInput,
      inspectedBusinessId,
    });
    try {
      window.sessionStorage.setItem(draftStorageKey, serialized);
    } catch {
      // Ignore storage errors
    }
    try {
      window.localStorage.setItem(draftStorageKey, serialized);
    } catch {
      // Ignore storage errors
    }
  }, [
    searchQuery,
    statusFilter,
    formOpen,
    editingBusiness,
    nameInput,
    typeInput,
    contactEmailInput,
    phoneInput,
    addressInput,
    ownerNameInput,
    ownerEmailInput,
    ownerUidInput,
    initialShopNameInput,
    initialShopCategoryInput,
    initialShopCityInput,
    initialShopAddressInput,
    notesInput,
    inspectedBusinessId,
  ]);

  const inspectedBusiness = useMemo(
    () => businesses.find((b) => b.id === inspectedBusinessId) ?? null,
    [businesses, inspectedBusinessId]
  );

  const filteredBusinesses = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return businesses.filter((b) => {
      if (statusFilter !== 'all' && b.status !== statusFilter) return false;
      if (!q) return true;
      return (
        b.name.toLowerCase().includes(q) ||
        b.id.toLowerCase().includes(q) ||
        b.ownerName.toLowerCase().includes(q) ||
        b.ownerEmail.toLowerCase().includes(q) ||
        b.businessType.toLowerCase().includes(q)
      );
    });
  }, [businesses, searchQuery, statusFilter]);

  const activeBizCount = businesses.filter((b) => b.status === 'active').length;
  const suspendedBizCount = businesses.filter(
    (b) => b.status === 'suspended'
  ).length;
  const businessOwners = useMemo(
    () => getAdminPageBusinessOwners(users),
    [users]
  );
  const businessOwnersCount = businessOwners.length;

  const adminSwitcherUsers = useMemo(
    () => getVisibleUsersForActor(currentUser, users),
    [currentUser, users]
  );

  const filteredBusinessOwners = useMemo(() => {
    const q = userSearchQuery.trim().toLowerCase();
    return businessOwners.filter((u) => {
      if (userBusinessFilter !== 'all' && u.businessId !== userBusinessFilter) {
        return false;
      }
      if (!q) return true;
      const parentBiz = businesses.find((b) => b.id === u.businessId);
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        u.businessId.toLowerCase().includes(q) ||
        (parentBiz && parentBiz.name.toLowerCase().includes(q))
      );
    });
  }, [businessOwners, businesses, userSearchQuery, userBusinessFilter]);

  const openCreateModal = () => {
    setEditingBusiness(null);
    setNameInput('');
    setTypeInput(BUSINESS_TYPES[0]);
    setContactEmailInput('');
    setPhoneInput('');
    setAddressInput('');
    setOwnerNameInput('');
    setOwnerEmailInput('');
    setOwnerUidInput('');
    setInitialShopNameInput('');
    setInitialShopCategoryInput('Supermarket');
    setInitialShopCityInput('Lagos');
    setInitialShopAddressInput('');
    setNotesInput('');
    setFormError(null);
    setFormOpen(true);
  };

  const openEditModal = (biz: Business) => {
    setEditingBusiness(biz);
    setNameInput(biz.name);
    setTypeInput(biz.businessType);
    setContactEmailInput(biz.contactEmail);
    setPhoneInput(biz.primaryPhone);
    setAddressInput(biz.headquartersAddress);
    setOwnerNameInput(biz.ownerName);
    setOwnerEmailInput(biz.ownerEmail);
    setOwnerUidInput(biz.ownerUserId);
    setNotesInput(biz.notes ?? '');
    setFormError(null);
    setFormOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: CreateBusinessInput = {
      name: nameInput,
      businessType: typeInput,
      contactEmail: contactEmailInput,
      primaryPhone: phoneInput,
      headquartersAddress: addressInput,
      ownerName: ownerNameInput,
      ownerEmail: ownerEmailInput,
      ownerUid: ownerUidInput.trim() || undefined,
      initialShopName: initialShopNameInput.trim() || undefined,
      initialShopCategory: initialShopCategoryInput.trim() || undefined,
      initialShopCity: initialShopCityInput.trim() || undefined,
      initialShopAddress: initialShopAddressInput.trim() || undefined,
      notes: notesInput,
    };

    const validation = validateBusinessRegistrationInput(
      payload,
      businesses,
      users,
      editingBusiness?.id
    );
    if (!validation.valid) {
      setFormError(validation.error ?? 'Please check the business details.');
      return;
    }

    if (editingBusiness) {
      onUpdateBusiness(editingBusiness.id, payload);
      setFeedbackBanner(
        `Updated business "${payload.name.trim()}" (${editingBusiness.id}) and primary owner assignment.`
      );
    } else {
      const created = onCreateBusiness(payload);
      setFeedbackBanner(
        `Registered new business "${created.name}" (${created.id}), primary owner ${created.ownerName} (${created.ownerEmail}), and initial shop in ${
          isDemoMode ? 'isolated demo repository' : `Cloud Firestore (${firestoreDatabaseId})`
        }.`
      );
    }
    setFormOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top Bar */}
      <header className="h-16 bg-slate-900 text-white border-b border-slate-800 px-3 sm:px-6 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-display font-bold text-sm shrink-0">
            SM
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-sm sm:text-base text-white truncate">
                SmartMind POS
              </span>
              <span className="hidden sm:inline-block text-xs font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded whitespace-nowrap">
                Platform Administration Console
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate hidden lg:block">
              {isDemoMode
                ? 'Multi-Business Tenant Registry & Primary Owner Provisioning (Isolated Demo Repository)'
                : `Multi-Business Tenant Registry & Primary Owner Provisioning (Cloud Firestore: ${firestoreDatabaseId})`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Role Switcher ONLY in Demo Mode */}
          {isDemoMode && (
            <div className="hidden md:flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <label htmlFor="platform-role-switcher" className="text-xs text-slate-300">
                Test Role:
              </label>
              <select
                id="platform-role-switcher"
                aria-label="Switch Demo User Role"
                value={currentUser.id}
                onChange={(e) => onSwitchDemoUser(e.target.value)}
                className="bg-slate-900 text-white text-xs font-medium rounded px-2 py-1 border border-slate-700 focus:outline-none focus:border-emerald-500"
              >
                {adminSwitcherUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName} — {u.role === 'platform_admin' ? 'Platform Administrator' : 'Business Owner'}
                  </option>
                ))}
              </select>
            </div>
          )}

          {isDemoMode && (
            <ConnectivityStatusControl
              snapshot={connectivity}
              onChangeState={onChangeConnectivityState}
            />
          )}

          <button
            type="button"
            onClick={onSignOut}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition-colors cursor-pointer min-h-[38px]"
          >
            <LogOut className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-3.5 sm:p-5 lg:p-6 space-y-4 sm:space-y-6">
        {/* Role & Security Boundary Notice */}
        <section
          aria-label="Platform Administrator Governance Notice"
          className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-lg font-display font-bold text-slate-900">
                  Business Management &amp; Tenant Registry
                </h1>
                {dataMode === 'live' ? (
                  <span className="text-xs font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                    Live Cloud Firestore Repository ({firestoreDatabaseId})
                  </span>
                ) : dataMode === 'offline_live' ? (
                  <span className="text-xs font-mono text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                    Offline Cached Live Repository ({firestoreDatabaseId})
                  </span>
                ) : (
                  <span className="text-xs font-mono text-indigo-800 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                    Isolated Demo Mode (Sample Repository)
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Signed in as <strong>{currentUser.fullName}</strong> (Platform Administrator). You can register businesses, assign each business’s single primary owner account, and manage business access status. Platform administrators are not business owners and do not automatically inherit unrestricted access to shop POS transactions.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={openCreateModal}
              className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer whitespace-nowrap min-h-[40px]"
            >
              <Plus className="w-4 h-4" />
              <span>Create Business</span>
            </button>
          </div>
        </section>

        {feedbackBanner && (
          <div
            role="status"
            className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-3 text-xs text-emerald-900"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-medium">{feedbackBanner}</span>
            </div>
            <button
              type="button"
              onClick={() => setFeedbackBanner(null)}
              aria-label="Dismiss notification"
              className="text-emerald-700 hover:text-emerald-950 font-semibold"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Summary Metrics */}
        <section
          aria-label="Platform Tenant Metrics"
          className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4"
        >
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs font-medium text-slate-500">
              Registered Businesses
            </p>
            <p className="text-2xl font-display font-bold text-slate-900 font-mono tabular-nums mt-1">
              {businesses.length}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {activeBizCount} active · {suspendedBizCount} suspended
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs font-medium text-slate-500">
              Registered Business Owners
            </p>
            <p className="text-2xl font-display font-bold text-emerald-700 font-mono tabular-nums mt-1">
              {businessOwnersCount}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Only business owners listed here
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs font-medium text-slate-500">
              Total Registered Shops
            </p>
            <p className="text-2xl font-display font-bold text-slate-900 font-mono tabular-nums mt-1">
              {shops.length}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Across all registered businesses
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <p className="text-xs font-medium text-slate-500">
              Tenant User Hierarchy
            </p>
            <p className="text-sm font-display font-bold text-emerald-700 mt-2">
              Owners Only on Admin Page
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Staff visible inside owner dashboard
            </p>
          </div>
        </section>

        {/* Search & Filter Bar + Business Table */}
        <section
          aria-label="Registered Businesses Directory"
          className="bg-white rounded-xl border border-slate-200 overflow-hidden"
        >
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                aria-label="Search registered businesses"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by business name, ID, owner name, or email..."
                className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-emerald-600"
              />
            </div>

            <div className="flex items-center gap-2">
              <label htmlFor="biz-status-filter" className="text-xs text-slate-500">
                Status:
              </label>
              <select
                id="biz-status-filter"
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(e.target.value as 'all' | BusinessStatus)
                }
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-medium text-slate-700 focus:outline-none focus:border-emerald-600"
              >
                <option value="all">All Businesses ({businesses.length})</option>
                <option value="active">Active Only ({activeBizCount})</option>
                <option value="suspended">
                  Suspended Only ({suspendedBizCount})
                </option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs min-w-[820px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500">
                  <th className="py-3 px-4 font-semibold">Business Name</th>
                  <th className="py-3 px-4 font-semibold">Unique Business ID</th>
                  <th className="py-3 px-4 font-semibold">Primary Owner</th>
                  <th className="py-3 px-4 font-semibold text-right">
                    Registered Shops
                  </th>
                  <th className="py-3 px-4 font-semibold text-right">
                    Registered Users
                  </th>
                  <th className="py-3 px-4 font-semibold">Registration Date</th>
                  <th className="py-3 px-4 font-semibold">Account Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredBusinesses.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="py-10 px-4 text-center text-slate-500"
                    >
                      No registered businesses match your search criteria.
                    </td>
                  </tr>
                ) : (
                  filteredBusinesses.map((biz) => {
                    const bizShops = shops.filter((s) => s.businessId === biz.id);
                    const bizUsers = users.filter((u) => u.businessId === biz.id);
                    const isActive = biz.status === 'active';
                    return (
                      <tr
                        key={biz.id}
                        className="hover:bg-slate-50/80 transition-colors"
                      >
                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-slate-900">
                            {biz.name}
                          </p>
                          <p className="text-slate-500 mt-0.5">
                            {biz.businessType} · {biz.contactEmail}
                          </p>
                        </td>
                        <td className="py-3.5 px-4 font-mono text-slate-700 whitespace-nowrap">
                          {biz.id}
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-slate-900">
                            {biz.ownerName}
                          </p>
                          <p className="text-slate-500 font-mono">
                            {biz.ownerEmail}
                          </p>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                          {bizShops.length}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                          {bizUsers.length}
                        </td>
                        <td className="py-3.5 px-4 font-mono text-slate-600 whitespace-nowrap">
                          {biz.createdAt}
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1.5 font-semibold ${
                              isActive ? 'text-emerald-700' : 'text-red-700'
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                isActive ? 'bg-emerald-600' : 'bg-red-600'
                              }`}
                            />
                            {isActive ? 'Active' : 'Suspended'}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setInspectedBusinessId(biz.id)}
                              aria-label={`View ${biz.name}`}
                              className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-medium inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-500" />
                              <span>View</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => openEditModal(biz)}
                              aria-label={`Edit ${biz.name}`}
                              className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-medium inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-slate-500" />
                              <span>Edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                const next: BusinessStatus = isActive
                                  ? 'suspended'
                                  : 'active';
                                try {
                                  await onToggleBusinessStatus(biz.id, next);
                                  setFeedbackBanner(
                                    next === 'suspended'
                                      ? `Suspended business "${biz.name}" (${biz.id}). New authorized access is blocked while historical records remain intact.`
                                      : `Re-activated business "${biz.name}" (${biz.id}).`
                                  );
                                } catch {
                                  setFeedbackBanner(null);
                                }
                              }}
                              aria-label={`${
                                isActive ? 'Suspend' : 'Activate'
                              } ${biz.name}`}
                              className={`px-2.5 py-1.5 rounded-lg border font-medium inline-flex items-center gap-1 cursor-pointer ${
                                isActive
                                  ? 'border-amber-200 bg-amber-50 hover:bg-amber-100 text-amber-800'
                                  : 'border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              <Power className="w-3.5 h-3.5" />
                              <span>{isActive ? 'Suspend' : 'Activate'}</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Registered Business Owners Directory (Only Business Owners Listed Here) */}
        <section
          aria-label="All Registered Platform Users and Business Owners Directory"
          className="bg-white rounded-xl border border-slate-200 overflow-hidden"
        >
          <div className="p-4 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-slate-900 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-sm sm:text-base font-display font-bold text-slate-900">
                    All Registered Platform Users &amp; Business Owners ({businessOwnersCount})
                  </h2>
                  <span className="text-[11px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded">
                    Business Owners Only
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Only registered Business Owners are displayed on the Admin page (Shop Managers and Cashiers are not listed here). Click <strong>Access Business Dashboard</strong> on any Business Owner to open their page and view all users registered under that Business Owner.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[220px] flex-1 sm:flex-initial">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="search"
                  aria-label="Search registered business owners"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  placeholder="Search business owner name, email, or business..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <select
                aria-label="Filter business owners by business"
                value={userBusinessFilter}
                onChange={(e) => setUserBusinessFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-medium text-slate-700 focus:outline-none focus:border-emerald-600"
              >
                <option value="all">All Businesses ({businesses.length})</option>
                {businesses.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} ({b.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs min-w-[780px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500">
                  <th className="py-3 px-4 font-semibold">Business Owner Name &amp; Email</th>
                  <th className="py-3 px-4 font-semibold">Role</th>
                  <th className="py-3 px-4 font-semibold">Registered Business</th>
                  <th className="py-3 px-4 font-semibold">Shops &amp; Users Under Owner</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Business Page Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredBusinessOwners.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="py-8 px-4 text-center text-slate-500"
                    >
                      No registered business owners match your search filter.
                    </td>
                  </tr>
                ) : (
                  filteredBusinessOwners.map((u) => {
                    const parentBiz = businesses.find((b) => b.id === u.businessId);
                    const bizShops = shops.filter(
                      (s) => s.businessId === u.businessId
                    );
                    const usersUnderOwnerCount = users.filter(
                      (staff) =>
                        staff.businessId === u.businessId &&
                        staff.role !== 'platform_admin'
                    ).length;
                    return (
                      <tr
                        key={u.id}
                        className="hover:bg-slate-50/80 transition-colors"
                      >
                        <td className="py-3 px-4">
                          <p className="font-semibold text-slate-900">{u.fullName}</p>
                          <p className="font-mono text-slate-500 text-[11px]">
                            {u.email} · ID: {u.id}
                          </p>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="inline-flex items-center px-2 py-0.5 rounded font-semibold text-[11px] bg-emerald-100 text-emerald-900">
                            Business Owner
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {parentBiz ? (
                            <div>
                              <p className="font-semibold text-slate-900">
                                {parentBiz.name}
                              </p>
                              <p className="font-mono text-[11px] text-slate-500">
                                {parentBiz.id}
                              </p>
                            </div>
                          ) : (
                            <span className="font-mono text-slate-500">
                              {u.businessId}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-emerald-700 font-semibold">
                            {bizShops.length} shop{bizShops.length === 1 ? '' : 's'}
                          </span>
                          <span className="text-slate-400 mx-1.5">·</span>
                          <span className="text-slate-600 font-mono">
                            {usersUnderOwnerCount} user{usersUnderOwnerCount === 1 ? '' : 's'} under owner
                          </span>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1.5 font-semibold capitalize ${
                              u.status === 'active'
                                ? 'text-emerald-700'
                                : 'text-red-700'
                            }`}
                          >
                            <span
                              className={`w-2 h-2 rounded-full ${
                                u.status === 'active'
                                  ? 'bg-emerald-600'
                                  : 'bg-red-600'
                              }`}
                            />
                            {u.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          {isDemoMode ? (
                            <button
                              type="button"
                              onClick={() => onSwitchDemoUser(u.id)}
                              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer inline-flex items-center gap-1.5 shadow-2xs"
                            >
                              <span>Access Business Dashboard</span>
                            </button>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-600 font-mono text-[11px]">
                              <Lock className="w-3 h-3 text-slate-400" />
                              Isolated Tenant (Owner Auth Required)
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>
      </main>

      {/* CREATE / EDIT BUSINESS MODAL */}
      {formOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="business-modal-title"
          className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full overflow-hidden shadow-xl max-h-[92vh] flex flex-col">
            <div className="px-5 sm:px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <h2
                  id="business-modal-title"
                  className="text-base font-display font-bold"
                >
                  {editingBusiness
                    ? `Edit Business · ${editingBusiness.id}`
                    : 'Register New Business & Primary Owner'}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                aria-label="Close business form"
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-4 sm:p-6 space-y-4 text-xs overflow-y-auto" noValidate>
              {formError && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-red-50 border border-red-200 flex items-start gap-2 text-red-800"
                >
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="biz-form-name"
                    className="block font-semibold text-slate-700 mb-1"
                  >
                    Business Name *
                  </label>
                  <input
                    id="biz-form-name"
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="e.g. Crestview Pharmacy Group"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="biz-form-type"
                    className="block font-semibold text-slate-700 mb-1"
                  >
                    Business Type *
                  </label>
                  <select
                    id="biz-form-type"
                    value={typeInput}
                    onChange={(e) => setTypeInput(e.target.value as BusinessType)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 bg-white focus:outline-none focus:border-emerald-600"
                  >
                    {BUSINESS_TYPES.map((bt) => (
                      <option key={bt} value={bt}>
                        {bt}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="biz-form-contact-email"
                    className="block font-semibold text-slate-700 mb-1"
                  >
                    Business Contact Email *
                  </label>
                  <input
                    id="biz-form-contact-email"
                    type="email"
                    value={contactEmailInput}
                    onChange={(e) => setContactEmailInput(e.target.value)}
                    placeholder="e.g. contact@crestview.demo"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="biz-form-phone"
                    className="block font-semibold text-slate-700 mb-1"
                  >
                    Phone Number *
                  </label>
                  <input
                    id="biz-form-phone"
                    type="text"
                    value={phoneInput}
                    onChange={(e) => setPhoneInput(e.target.value)}
                    placeholder="e.g. +234 802 300 4400"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label
                    htmlFor="biz-form-address"
                    className="block font-semibold text-slate-700 mb-1"
                  >
                    Business Address *
                  </label>
                  <input
                    id="biz-form-address"
                    type="text"
                    value={addressInput}
                    onChange={(e) => setAddressInput(e.target.value)}
                    placeholder="e.g. 22 Awolowo Road, Ikoyi, Lagos"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <p className="font-display font-bold text-slate-900 text-xs mb-1">
                  Single Primary Owner Assignment
                </p>
                <p className="text-slate-500 text-xs mb-3">
                  Each business must have exactly one primary owner account. Duplicate owner assignments across businesses are prevented.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label
                      htmlFor="biz-form-owner-name"
                      className="block font-semibold text-slate-700 mb-1"
                    >
                      Primary Owner’s Full Name *
                    </label>
                    <input
                      id="biz-form-owner-name"
                      type="text"
                      value={ownerNameInput}
                      onChange={(e) => setOwnerNameInput(e.target.value)}
                      placeholder="e.g. Dr. Folake Coker"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="biz-form-owner-email"
                      className="block font-semibold text-slate-700 mb-1"
                    >
                      Primary Owner’s Email *
                    </label>
                    <input
                      id="biz-form-owner-email"
                      type="email"
                      value={ownerEmailInput}
                      onChange={(e) => setOwnerEmailInput(e.target.value)}
                      placeholder="e.g. owner@crestview.com"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                    />
                  </div>

                  {!editingBusiness && (
                    <div className="sm:col-span-2">
                      <label
                        htmlFor="biz-form-owner-uid"
                        className="block font-semibold text-slate-700 mb-1"
                      >
                        Primary Owner’s Firebase Auth UID (Optional if pre-registered; required for direct client Firestore login before Cloud Functions deployment)
                      </label>
                      <input
                        id="biz-form-owner-uid"
                        type="text"
                        value={ownerUidInput}
                        onChange={(e) => setOwnerUidInput(e.target.value)}
                        placeholder="Paste owner's Firebase UID from their onboarding screen (or leave blank to generate placeholder)"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono focus:outline-none focus:border-emerald-600"
                      />
                    </div>
                  )}
                </div>
              </div>

              {!editingBusiness && (
                <div className="pt-3 border-t border-slate-200">
                  <p className="font-display font-bold text-slate-900 text-xs mb-1">
                    Initial Shop (First Branch) Provisioning
                  </p>
                  <p className="text-slate-500 text-xs mb-3">
                    Provisions the business’s first operational shop and assigns the Primary Owner to it in Firestore.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label
                        htmlFor="biz-form-shop-name"
                        className="block font-semibold text-slate-700 mb-1"
                      >
                        First Shop Name
                      </label>
                      <input
                        id="biz-form-shop-name"
                        type="text"
                        value={initialShopNameInput}
                        onChange={(e) => setInitialShopNameInput(e.target.value)}
                        placeholder="Defaults to Main Branch"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="biz-form-shop-category"
                        className="block font-semibold text-slate-700 mb-1"
                      >
                        Shop Category
                      </label>
                      <input
                        id="biz-form-shop-category"
                        type="text"
                        value={initialShopCategoryInput}
                        onChange={(e) =>
                          setInitialShopCategoryInput(e.target.value)
                        }
                        placeholder="Supermarket"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="biz-form-shop-city"
                        className="block font-semibold text-slate-700 mb-1"
                      >
                        Shop City
                      </label>
                      <input
                        id="biz-form-shop-city"
                        type="text"
                        value={initialShopCityInput}
                        onChange={(e) => setInitialShopCityInput(e.target.value)}
                        placeholder="Lagos"
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label
                  htmlFor="biz-form-notes"
                  className="block font-semibold text-slate-700 mb-1"
                >
                  Optional Notes
                </label>
                <textarea
                  id="biz-form-notes"
                  rows={2}
                  value={notesInput}
                  onChange={(e) => setNotesInput(e.target.value)}
                  placeholder="Optional onboarding notes or branch license details..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold cursor-pointer"
                >
                  {editingBusiness ? 'Save Business Changes' : 'Register Business'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW BUSINESS & REGISTERED SHOPS MODAL */}
      {inspectedBusiness && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="inspect-biz-title"
          className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full overflow-hidden shadow-xl max-h-[92vh] flex flex-col">
            <div className="px-5 sm:px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-xs font-mono text-emerald-400">
                  Business ID: {inspectedBusiness.id}
                </span>
                <h2
                  id="inspect-biz-title"
                  className="text-base font-display font-bold mt-0.5"
                >
                  {inspectedBusiness.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setInspectedBusinessId(null)}
                aria-label="Close business details"
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6 space-y-4 sm:space-y-5 text-xs overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="space-y-1.5">
                  <p className="text-slate-500 font-medium">Business Details</p>
                  <p className="font-semibold text-slate-900">
                    {inspectedBusiness.businessType}
                  </p>
                  <p className="flex items-center gap-1.5 text-slate-600">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>{inspectedBusiness.contactEmail}</span>
                  </p>
                  <p className="flex items-center gap-1.5 text-slate-600 font-mono">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{inspectedBusiness.primaryPhone}</span>
                  </p>
                  <p className="flex items-center gap-1.5 text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{inspectedBusiness.headquartersAddress}</span>
                  </p>
                </div>

                <div className="space-y-1.5">
                  <p className="text-slate-500 font-medium">
                    Assigned Primary Owner (Single Owner Rule)
                  </p>
                  <p className="font-semibold text-slate-900">
                    {inspectedBusiness.ownerName}
                  </p>
                  <p className="font-mono text-slate-700">
                    {inspectedBusiness.ownerEmail}
                  </p>
                  <p className="font-mono text-slate-500">
                    Owner User ID: {inspectedBusiness.ownerUserId}
                  </p>
                  <p className="text-slate-600">
                    Status:{' '}
                    <strong className="uppercase">
                      {inspectedBusiness.status}
                    </strong>{' '}
                    · Registered: {inspectedBusiness.createdAt}
                  </p>
                </div>
              </div>

              {/* Registered Shops under this business */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="font-display font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Store className="w-4 h-4 text-emerald-700" />
                    <span>
                      Shops Registered Under {inspectedBusiness.name} (
                      {
                        shops.filter(
                          (s) => s.businessId === inspectedBusiness.id
                        ).length
                      }
                      )
                    </span>
                  </h3>
                  <span className="text-xs text-slate-500 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-slate-400" />
                    <span>POS transactions isolated to business staff</span>
                  </span>
                </div>

                {shops.filter((s) => s.businessId === inspectedBusiness.id)
                  .length === 0 ? (
                  <div className="p-6 rounded-xl border border-slate-200 text-center text-slate-500">
                    No shops registered under this business yet. The Business Owner can create shops after signing in.
                  </div>
                ) : (
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500">
                          <th className="py-2.5 px-3 font-semibold">Shop Name</th>
                          <th className="py-2.5 px-3 font-semibold">Shop ID</th>
                          <th className="py-2.5 px-3 font-semibold">Location</th>
                          <th className="py-2.5 px-3 font-semibold">Status</th>
                          <th className="py-2.5 px-3 font-semibold">Created</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {shops
                          .filter((s) => s.businessId === inspectedBusiness.id)
                          .map((shop) => (
                            <tr key={shop.id}>
                              <td className="py-2.5 px-3 font-semibold text-slate-900">
                                {shop.name} ({shop.code})
                              </td>
                              <td className="py-2.5 px-3 font-mono text-slate-700">
                                {shop.id}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600">
                                {shop.address}, {shop.locationCity}
                              </td>
                              <td className="py-2.5 px-3 uppercase font-semibold text-emerald-700">
                                {shop.status}
                              </td>
                              <td className="py-2.5 px-3 font-mono text-slate-500">
                                {shop.createdAt}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                {isDemoMode ? (
                  <button
                    type="button"
                    onClick={() => {
                      const ownerUser = users.find(
                        (u) => u.id === inspectedBusiness.ownerUserId
                      );
                      if (ownerUser) {
                        setInspectedBusinessId(null);
                        onSwitchDemoUser(ownerUser.id);
                      }
                    }}
                    className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 underline cursor-pointer"
                  >
                    Access Business Dashboard as Primary Owner ({inspectedBusiness.ownerName})
                  </button>
                ) : (
                  <span className="text-xs text-slate-500 font-mono">
                    Tenant Isolation Enforced · Primary Owner must sign in directly
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setInspectedBusinessId(null)}
                  className="px-4 py-2 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800 cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
