import { app, BrowserWindow, ipcMain, shell } from 'electron';
import * as http from 'node:http';
import * as path from 'node:path';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

/**
 * SmartMind POS — Stage 1: Electron Desktop Main Process
 *
 * Professional Windows Desktop Foundation for SmartMind POS.
 *
 * Architecture & Security Standards:
 * - Single-instance application lock for POS terminal reliability
 * - contextIsolation: true, nodeIntegration: false, sandbox: true
 * - Navigation lock: Prevents renderer hijacking; external URLs open in system browser
 * - Development: Automatically waits for Vite dev server (port 3000)
 * - Production: Loads built assets from dist/index.html
 * - Window state & lifecycle management tailored for POS cashier and manager workflows
 */

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let mainWindow: BrowserWindow | null = null;

// Determine environment
const isDev =
  !app.isPackaged &&
  (process.env.ELECTRON_DEV === 'true' ||
    process.env.NODE_ENV === 'development' ||
    process.env.VITE_DEV_SERVER_URL !== undefined);

const DEV_SERVER_URL = process.env.VITE_DEV_SERVER_URL || 'http://localhost:3000';

// Public OAuth client identifier for the installed Windows desktop application.
// Desktop OAuth clients use PKCE; no client secret is embedded in this application.
const GOOGLE_DESKTOP_CLIENT_ID =
  '226496655699-om9lkbmlo4tevfejb8d1t49kuqbbngdq.apps.googleusercontent.com';

// Acquire single-instance lock to ensure only one POS process runs per terminal
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  console.warn('[SmartMind POS] Another instance of SmartMind POS is already running. Quitting.');
  app.quit();
} else {
  app.on('second-instance', () => {
    // If a second instance is launched, focus the existing window
    if (mainWindow) {
      if (mainWindow.isMinimized()) {
        mainWindow.restore();
      }
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    registerIpcHandlers();
    createMainWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow();
      }
    });
  });
}

/**
 * Helper to wait for the local Vite dev server before loading
 */
function waitForDevServer(url: string, maxAttempts = 30, intervalMs = 300): Promise<boolean> {
  return new Promise((resolve) => {
    let attempts = 0;

    const check = () => {
      attempts++;
      const req = http.get(url, (res) => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 400) {
          resolve(true);
        } else if (attempts < maxAttempts) {
          setTimeout(check, intervalMs);
        } else {
          resolve(false);
        }
      });

      req.on('error', () => {
        if (attempts < maxAttempts) {
          setTimeout(check, intervalMs);
        } else {
          resolve(false);
        }
      });

      req.setTimeout(1000, () => {
        req.destroy();
        if (attempts < maxAttempts) {
          setTimeout(check, intervalMs);
        } else {
          resolve(false);
        }
      });
    };

    check();
  });
}

/**
 * Creates and configures the primary POS BrowserWindow
 */
async function createMainWindow(): Promise<void> {
  const iconPath = path.join(__dirname, '../public/assets/aistudio/smartmind_pos_4bb52e16.png');

  mainWindow = new BrowserWindow({
    title: 'SmartMind POS',
    width: 1366,
    height: 860,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: '#0f172a',
    icon: iconPath,
    show: false, // Prevent white flash until ready
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
  });

  // Smooth appearance when ready
  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
    if (isDev) {
      mainWindow?.webContents.openDevTools({ mode: 'detach' });
    }
  });

  // Security: Deny window.open requests and open external links safely in user's OS browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http:') || url.startsWith('https:')) {
      shell.openExternal(url).catch((err) => {
        console.error('[SmartMind POS] Failed to open external URL:', err);
      });
    }
    return { action: 'deny' };
  });

  // Security: Allow only the exact application origin.
  mainWindow.webContents.on('will-navigate', (event, url) => {
    let allowed = false;

    try {
      const target = new URL(url);

      if (isDev) {
        allowed = target.origin === new URL(DEV_SERVER_URL).origin;
      } else {
        const expectedFile = pathToFileURL(
          path.join(__dirname, '../dist/index.html')
        ).href;
        allowed = target.href === expectedFile;
      }
    } catch {
      allowed = false;
    }

    if (!allowed) {
      event.preventDefault();

      try {
        const target = new URL(url);
        if (target.protocol === 'https:' || target.protocol === 'http:') {
          shell.openExternal(target.href).catch((err) => {
            console.error('[SmartMind POS] Failed to open external URL:', err);
          });
        }
      } catch {
        console.warn('[SmartMind POS] Blocked invalid navigation URL.');
      }
    }
  });

  // Load the application based on environment
  if (isDev) {
    console.log(`[SmartMind POS] Development mode active. Connecting to dev server at ${DEV_SERVER_URL}...`);
    const serverReady = await waitForDevServer(DEV_SERVER_URL);
    if (serverReady) {
      await mainWindow.loadURL(DEV_SERVER_URL);
    } else {
      console.warn(`[SmartMind POS] Dev server at ${DEV_SERVER_URL} was not reachable within timeout. Loading fallback.`);
      await mainWindow.loadURL(DEV_SERVER_URL); // Let Chromium display connection info or retry
    }
  } else {
    const indexPath = path.join(__dirname, '../dist/index.html');
    console.log(`[SmartMind POS] Production mode active. Loading local assets from ${indexPath}...`);
    await mainWindow.loadFile(indexPath);
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}


interface GoogleTokenResponse {
  id_token?: string;
  error?: string;
  error_description?: string;
}

function isLoopbackAddress(address?: string): boolean {
  if (!address) return false;
  return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1';
}

function assertTrustedRenderer(event: Electron.IpcMainInvokeEvent): void {
  if (!mainWindow || event.sender !== mainWindow.webContents) {
    throw new Error('AUTH_SECURITY_ERROR: Untrusted renderer.');
  }

  const frameUrl = event.senderFrame?.url;
  if (!frameUrl) throw new Error('AUTH_SECURITY_ERROR: Missing renderer frame.');

  try {
    const actual = new URL(frameUrl);
    if (isDev) {
      if (actual.origin !== new URL(DEV_SERVER_URL).origin) {
        throw new Error('AUTH_SECURITY_ERROR: Renderer origin is not allowed.');
      }
    } else {
      const expected = pathToFileURL(path.join(__dirname, '../dist/index.html'));
      if (actual.protocol !== 'file:' || actual.href !== expected.href) {
        throw new Error('AUTH_SECURITY_ERROR: Renderer file is not allowed.');
      }
    }
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('AUTH_SECURITY_ERROR:')) throw error;
    throw new Error('AUTH_SECURITY_ERROR: Invalid renderer origin.');
  }
}

async function runGoogleDesktopOAuth(): Promise<{ idToken: string }> {
  const state = randomBytes(32).toString('base64url');
  const verifier = randomBytes(48).toString('base64url');
  const challenge = createHash('sha256').update(verifier).digest('base64url');

  const server = http.createServer();
  let callbackSettled = false;
  let timeout: NodeJS.Timeout | undefined;

  const callbackResult = new Promise<string>((resolve, reject) => {
    const finish = (error?: Error, code?: string) => {
      if (callbackSettled) return;
      callbackSettled = true;
      if (timeout) clearTimeout(timeout);
      if (error) reject(error);
      else if (code) resolve(code);
      else reject(new Error('Google OAuth callback did not contain an authorization code.'));
    };

    server.on('request', (req, res) => {
      if (!isLoopbackAddress(req.socket.remoteAddress) || req.method !== 'GET') {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Forbidden');
        return;
      }

      const host = req.headers.host || '';
      if (!/^127\.0\.0\.1:\d+$/.test(host)) {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Invalid callback host.');
        return;
      }

      const requestUrl = new URL(req.url || '/', `http://${host}`);
      if (requestUrl.pathname !== '/') {
        res.writeHead(404);
        res.end('Not found');
        return;
      }

      const returnedState = requestUrl.searchParams.get('state') || '';
      const expectedBuffer = Buffer.from(state);
      const receivedBuffer = Buffer.from(returnedState);
      const validState =
        expectedBuffer.length === receivedBuffer.length &&
        timingSafeEqual(expectedBuffer, receivedBuffer);

      if (!validState) {
        res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h2>SmartMind POS sign-in failed</h2><p>Invalid OAuth state. Return to the application and try again.</p>');
        finish(new Error('Google sign-in failed state validation.'));
        return;
      }

      const oauthError = requestUrl.searchParams.get('error');
      if (oauthError) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h2>Google sign-in was not completed</h2><p>You can close this tab and return to SmartMind POS.</p>');
        finish(new Error(`Google sign-in was not completed: ${oauthError}`));
        return;
      }

      const code = requestUrl.searchParams.get('code');
      if (!code) {
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Missing authorization code.');
        finish(new Error('Google did not return an authorization code.'));
        return;
      }

      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<!doctype html><html><head><meta charset="utf-8"><title>SmartMind POS</title></head><body style="font-family:Arial,sans-serif;padding:40px"><h2>Google sign-in completed</h2><p>Return to SmartMind POS. You may close this tab.</p></body></html>');
      finish(undefined, code);
    });

    timeout = setTimeout(() => finish(new Error('Google sign-in timed out. Please try again.')), 180_000);
    timeout.unref();
  });

  // Prevent an unhandled rejection if opening the system browser itself fails.
  void callbackResult.catch(() => undefined);

  try {
    await new Promise<void>((resolve, reject) => {
      server.once('error', reject);
      server.listen(0, '127.0.0.1', () => {
        server.removeListener('error', reject);
        resolve();
      });
    });

    const address = server.address();
    if (!address || typeof address === 'string') {
      throw new Error('Unable to start the local Google sign-in callback.');
    }

    const redirectUri = `http://127.0.0.1:${address.port}`;
    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.search = new URLSearchParams({
      client_id: GOOGLE_DESKTOP_CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'openid email profile',
      state,
      code_challenge: challenge,
      code_challenge_method: 'S256',
      prompt: 'select_account',
    }).toString();

    await shell.openExternal(authUrl.toString());
    const authorizationCode = await callbackResult;

    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: GOOGLE_DESKTOP_CLIENT_ID,
        code: authorizationCode,
        code_verifier: verifier,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });

    const tokenData = (await tokenResponse.json()) as GoogleTokenResponse;
    if (!tokenResponse.ok || !tokenData.id_token) {
      const reason = tokenData.error_description || tokenData.error || 'Google did not return an ID token.';
      throw new Error(`Google token exchange failed: ${reason}`);
    }

    return { idToken: tokenData.id_token };
  } finally {
    if (timeout) clearTimeout(timeout);
    if (server.listening) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  }
}

/**
 * Registers safe, non-privileged IPC communication channels
 */
function registerIpcHandlers(): void {
  // Google OAuth is handled entirely in the privileged main process.
  ipcMain.handle('smartmind:auth-google', async (event) => {
    assertTrustedRenderer(event);
    return await runGoogleDesktopOAuth();
  });

  // Information channel
  ipcMain.handle('smartmind:get-desktop-info', () => {
    return {
      isElectron: true,
      platform: process.platform,
      arch: process.arch,
      appVersion: app.getVersion(),
      electronVersion: process.versions.electron,
      chromeVersion: process.versions.chrome,
      nodeVersion: process.versions.node,
    };
  });

  // Window control channels
  ipcMain.handle('smartmind:window-minimize', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    win?.minimize();
  });

  ipcMain.handle('smartmind:window-maximize', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (!win) return;
    if (win.isMaximized()) {
      win.unmaximize();
    } else {
      win.maximize();
    }
  });

  ipcMain.handle('smartmind:window-close', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    win?.close();
  });

  ipcMain.handle('smartmind:window-is-maximized', (event) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    return win?.isMaximized() ?? false;
  });
}

// App lifecycle
app.on('window-all-closed', () => {
  // On POS terminals, closing the main window quits the application
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
