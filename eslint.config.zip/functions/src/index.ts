/**
 * SmartMind POS — Phase 6: Cloud Functions (2nd Gen / Node.js 22)
 *
 * Environment-specific Firebase configuration:
 * Production: gen-lang-client-0985802946
 * Staging: smartmind-pos-staging
 *
 * Firestore database selection is controlled by
 * NAMED_FIRESTORE_DATABASE_ID:
 * Production: ai-studio-smartmindpos-3ebff8f1-fed5-4111-b7db-f027e942fbb4
 * Staging: (default)
 *
 * CRITICAL SECURITY INVARIANTS ENFORCED BY THIS MODULE:
 * 1. Explicit Firestore Database Binding: Always connects to the
 *    configured database via getFirestore(app, NAMED_FIRESTORE_DATABASE_ID).
 *    Never relies on implicit database selection.
 */

const serverEnvironment =
  typeof process !== 'undefined' ? process.env : undefined;

export const EXPECTED_FIREBASE_PROJECT_ID =
  serverEnvironment?.SMARTMIND_EXPECTED_PROJECT_ID?.trim() ||
  'gen-lang-client-0985802946';

export const NAMED_FIRESTORE_DATABASE_ID =
  serverEnvironment?.FIRESTORE_DATABASE_ID?.trim() ||
  serverEnvironment?.VITE_FIREBASE_FIRESTORE_DATABASE_ID?.trim() ||
  'ai-studio-smartmindpos-3ebff8f1-fed5-4111-b7db-f027e942fbb4';

export const BOOTSTRAP_PLATFORM_ADMIN_EMAIL = 'smartnwokolo@gmail.com';
export const PLATFORM_ADMIN_BUSINESS_SENTINEL = 'PLATFORM';
export const VALID_PLATFORM_ADMIN_SENTINELS = new Set<string>([
  'PLATFORM',
  '__PLATFORM_ADMIN__',
  'platform_admin',
  'biz-platform-live',
]);
export const PRE_FIREBASE_TEST_BUSINESS_ID = 'biz-0003-u42w';
export const PRE_FIREBASE_TEST_SHOP_ID = 'shop-0005-9i6p';
export const PRE_FIREBASE_QUARANTINE_REASON =
  'pre_firebase_test_transaction_missing_live_tenant';

export const QUARANTINED_PRE_FIREBASE_SYNC_IDS = new Set<string>([
  'sync-sale-1792837064449-h1dw',
  'sync-sale-1792840077667-3knj',
  'sync-sale-1792840085221-qjdb',
  'sync-sale-1792840089845-kc84',
]);

export const QUARANTINED_PRE_FIREBASE_SALE_IDS = new Set<string>([
  'sale-1792837064449-h1dw',
  'sale-1792840077667-3knj',
  'sale-1792840085221-qjdb',
  'sale-1792840089845-kc84',
]);

export const KNOWN_DEMO_BUSINESS_IDS = new Set<string>([
  'biz-platform-hq',
  'biz-emerald-01',
  'biz-zenith-02',
  'biz-horizon-02',
  'biz-royal-03',
]);

export const KNOWN_DEMO_SHOP_IDS = new Set<string>([
  'shop-vi-01',
  'shop-ikj-02',
  'shop-ikeja-02',
  'shop-lek-03',
  'shop-lekki-03',
  'shop-abj-01',
  'shop-abuja-01',
  'shop-phc-01',
]);

export const KNOWN_DEMO_USER_IDS = new Set<string>([
  'usr-platform-admin',
  'usr-owner-01',
  'usr-mgr-vi',
  'usr-cashier-vi',
  'usr-mgr-ikj',
  'usr-cashier-ikj',
  'usr-mgr-lek',
  'usr-owner-02',
  'usr-owner-03',
]);

export const DEFAULT_BUSINESS_OWNER_PERMISSIONS = [
  'manage_business_settings',
  'manage_shops',
  'manage_staff',
  'manage_products',
  'adjust_inventory',
  'process_sales',
  'apply_discounts',
  'process_refunds',
  'process_returns',
  'view_shop_reports',
  'view_business_reports',
  'manage_debt_book',
  'manage_invoices',
] as const;

export const DEFAULT_SHOP_MANAGER_PERMISSIONS = [
  'manage_products',
  'adjust_inventory',
  'process_sales',
  'apply_discounts',
  'process_refunds',
  'process_returns',
  'view_shop_reports',
  'manage_debt_book',
  'manage_invoices',
] as const;

export const DEFAULT_CASHIER_PERMISSIONS = [
  'process_sales',
  'manage_invoices',
] as const;

export const OWNER_ONLY_PERMISSION_KEYS = new Set<string>([
  'manage_business_settings',
  'manage_shops',
  'manage_staff',
  'view_business_reports',
]);

export const MANAGER_ONLY_PERMISSION_KEYS = new Set<string>([
  'manage_products',
  'manage_catalogue',
  'manage_inventory',
  'manage_categories',
  'adjust_inventory',
  'adjust_stock',
  'process_refunds',
  'process_returns',
  'void_sale',
  'view_shop_reports',
]);

export const ALLOWED_CASHIER_PERMISSION_KEYS = new Set<string>([
  'process_sales',
  'process_sale',
  'pos_checkout',
  'manage_invoices',
  'manage_debt_book',
  'manage_customers',
  'manage_customers_debt',
  'apply_discounts',
  'apply_discount',
]);

export const ALLOWED_SHOP_MANAGER_PERMISSION_KEYS = new Set<string>([
  ...ALLOWED_CASHIER_PERMISSION_KEYS,
  ...MANAGER_ONLY_PERMISSION_KEYS,
]);

export const ALLOWED_STAFF_PERMISSION_KEYS = ALLOWED_SHOP_MANAGER_PERMISSION_KEYS;

export const ALL_SUPPORTED_PERMISSION_KEYS = new Set<string>([
  ...OWNER_ONLY_PERMISSION_KEYS,
  ...ALLOWED_SHOP_MANAGER_PERMISSION_KEYS,
]);

/**
 * Validates and deduplicates requested permissions for a staff role (`shop_manager` or `cashier`).
 * - Rejects non-array `requestedPermissions` when provided.
 * - Rejects unknown/unsupported permission identifiers.
 * - Rejects owner-only permissions (`manage_business_settings`, `manage_shops`, `manage_staff`, `view_business_reports`) for all staff.
 * - Rejects manager/inventory/refund/report permissions (`manage_products`, `adjust_inventory`, `process_refunds`, `process_returns`, `void_sale`, `view_shop_reports`, etc.) for `cashier`.
 */
export function validateRoleSpecificStaffPermissions(
  role: unknown,
  requestedPermissions?: unknown
): string[] {
  if (role !== 'shop_manager' && role !== 'cashier') {
    throw new Error(
      'PERMISSION_DENIED: Staff provisioning can only assign role "shop_manager" or "cashier" (never "business_owner" or "platform_admin").'
    );
  }

  if (requestedPermissions === undefined) {
    return role === 'shop_manager'
      ? [...DEFAULT_SHOP_MANAGER_PERMISSIONS]
      : [...DEFAULT_CASHIER_PERMISSIONS];
  }

  if (
    !Array.isArray(requestedPermissions) ||
    requestedPermissions.length === 0 ||
    requestedPermissions.length > 30
  ) {
    throw new Error(
      'INVALID_ARGUMENT: permissions must be a non-empty array of between 1 and 30 valid permission keys.'
    );
  }

  const validated: string[] = [];
  for (const rawPerm of requestedPermissions) {
    if (typeof rawPerm !== 'string' || rawPerm.trim().length === 0) {
      throw new Error(
        'INVALID_ARGUMENT: Every permission key must be a non-empty string.'
      );
    }
    const perm = rawPerm.trim();
    if (OWNER_ONLY_PERMISSION_KEYS.has(perm)) {
      throw new Error(
        `PERMISSION_DENIED: Staff accounts with role "${role}" cannot be granted owner-only permission "${perm}".`
      );
    }
    if (!ALL_SUPPORTED_PERMISSION_KEYS.has(perm)) {
      throw new Error(
        `INVALID_ARGUMENT: Unrecognized or unsupported staff permission key "${perm}".`
      );
    }
    if (role === 'cashier' && !ALLOWED_CASHIER_PERMISSION_KEYS.has(perm)) {
      throw new Error(
        `PERMISSION_DENIED: Cashier accounts cannot be granted manager, inventory-administration, refund, or shop-report permission "${perm}".`
      );
    }
    if (
      role === 'shop_manager' &&
      !ALLOWED_SHOP_MANAGER_PERMISSION_KEYS.has(perm)
    ) {
      throw new Error(
        `PERMISSION_DENIED: Shop Manager accounts cannot be granted permission "${perm}".`
      );
    }
    if (!validated.includes(perm)) {
      validated.push(perm);
    }
  }

  return validated;
}

export function callerHasPermission(
  callerProfile: Record<string, any>,
  allowedKeys: string[]
): boolean {
  if (callerProfile.role === 'business_owner') {
    return true;
  }
  const perms = Array.isArray(callerProfile.permissions)
    ? callerProfile.permissions
    : [];
  return perms.some((p: string) => allowedKeys.includes(p));
}

// ============================================================================
// TYPES & CONTRACTS
// ============================================================================

export interface CallableAuthContext {
  uid: string;
  token: {
    email?: string;
    email_verified?: boolean;
  };
}

export interface ProvisionBusinessRequest {
  idempotencyKey: string;
  businessId?: string;
  name: string;
  legalName?: string;
  businessType: string;
  registrationNumber?: string;
  taxIdentificationNumber?: string;
  contactEmail: string;
  primaryPhone: string;
  headquartersAddress: string;
  ownerUid?: string;
  ownerName: string;
  ownerEmail: string;
  currencyCode?: string;
  currencySymbol?: string;
  defaultTaxRatePercent?: number;
  notes?: string;
  initialShopId?: string;
  initialShopCode?: string;
  initialShopName?: string;
  initialShopCategory?: string;
  initialShopCity?: string;
  initialShopAddress?: string;
  initialShopPhone?: string;
}

export interface ProvisionBusinessResponse {
  status: 'provisioned' | 'idempotent_replay';
  isIdempotentReplay: boolean;
  databaseId: string;
  business: Record<string, any>;
  primaryOwner: Record<string, any>;
  firstShop: Record<string, any>;
}

export interface SyncPosSaleItemPayload {
  id: string;
  sale_id: string;
  shop_id: string;
  business_id: string;
  product_id: string;
  sku: string;
  barcode?: string;
  product_name: string;
  unit?: string;
  unit_price_kobo: number;
  cost_price_kobo?: number;
  quantity: number;
  line_total_kobo: number;
}

export interface SyncPosSalePayload {
  id: string;
  shop_id: string;
  business_id: string;
  receipt_number: string;
  terminal_id: string;
  cashier_user_id: string;
  cashier_name: string;
  created_at: string;
  subtotal_kobo: number;
  discount_amount_kobo: number;
  tax_rate_percent: number;
  tax_amount_kobo: number;
  total_amount_kobo: number;
  amount_tendered_kobo: number;
  change_due_kobo: number;
  payment_method: string;
  status: 'completed' | 'refunded' | 'voided';
  idempotency_key?: string;
}

export interface SyncOperationPayload {
  operationId: string;
  idempotencyKey: string;
  schemaVersion: number;
  businessId: string;
  shopId: string;
  entityType:
    | 'sale'
    | 'product'
    | 'category'
    | 'inventory_movement'
    | 'customer'
    | 'invoice'
    | 'payment';
  entityId: string;
  operationType: 'create' | 'update' | 'delete' | 'adjust';
  status?: string;
  /** Any client-supplied role claim is ignored by the server */
  clientClaimedRole?: string;
  payload: {
    sale?: SyncPosSalePayload;
    items?: SyncPosSaleItemPayload[];
    payment?: Record<string, any>;
    product?: Record<string, any>;
    category?: Record<string, any>;
    movement?: Record<string, any>;
    [key: string]: unknown;
  };
}

export interface SyncOperationResponse {
  outcome: 'acknowledged' | 'conflict_requires_review' | 'rejected_unauthorized';
  status: 'synced' | 'requires_review' | 'failed';
  databaseId: string;
  ackId?: string;
  syncedAt?: string;
  isDuplicateReplay?: boolean;
  conflictReason?: string;
  errorMessage?: string;
}

export interface InviteAuthorizedStaffRequest {
  idempotencyKey: string;
  businessId: string;
  staffUid?: string;
  fullName: string;
  email: string;
  role: 'shop_manager' | 'cashier';
  roleLabel?: string;
  assignedShopIds: string[];
  permissions?: string[];
}

export interface SetTenantStatusRequest {
  businessId: string;
  status: 'active' | 'suspended';
  reason?: string;
}

// ============================================================================
// TRANSACTIONAL DOCUMENT STORE & AUTH DIRECTORY ABSTRACTIONS
// ============================================================================

export interface ServerTransactionContext {
  getDoc(path: string): Promise<Record<string, any> | null>;
  queryDocsByField(
    collectionPath: string,
    field: string,
    value: string
  ): Promise<Array<Record<string, any>>>;
  setDoc(path: string, data: Record<string, any>): void;
}

export interface ServerDatabaseDriver {
  readonly databaseId: string;
  runTransaction<T>(
    updateFunction: (tx: ServerTransactionContext) => Promise<T>
  ): Promise<T>;
}

export interface ServerAuthDirectory {
  getUserByEmail(
    email: string
  ): Promise<{ uid: string; email: string; emailVerified?: boolean } | null>;
  getUserByUid(
    uid: string
  ): Promise<{ uid: string; email: string; emailVerified?: boolean } | null>;
}

// ============================================================================
// VALIDATION & QUARANTINE HELPERS
// ============================================================================

const SAFE_ID_REGEX = /^[a-zA-Z0-9_-]{1,128}$/;
const SAFE_EMAIL_REGEX = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const PRE_FIREBASE_BIZ_REGEX = /^biz-00\d\d-[a-z0-9]{4}$/i;
const PRE_FIREBASE_SHOP_REGEX = /^shop-00\d\d-[a-z0-9]{4}$/i;

export function isValidEntityId(value: unknown): value is string {
  return typeof value === 'string' && SAFE_ID_REGEX.test(value);
}

export function isValidEmailAddress(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    value.length >= 3 &&
    value.length <= 254 &&
    SAFE_EMAIL_REGEX.test(value)
  );
}

export function isQuarantinedOrDemoOperation(params: {
  operationId?: string;
  entityId?: string;
  businessId?: string;
  shopId?: string;
  status?: string;
}): { blocked: boolean; reason?: string } {
  const opId = params.operationId || '';
  const entityId = params.entityId || '';
  const bizId = params.businessId || '';
  const shopId = params.shopId || '';

  if (params.status === 'quarantined') {
    return {
      blocked: true,
      reason: `QUARANTINE_ENFORCED: Operation "${opId}" is marked quarantined and excluded from production sync.`,
    };
  }

  if (
    QUARANTINED_PRE_FIREBASE_SYNC_IDS.has(opId) ||
    QUARANTINED_PRE_FIREBASE_SALE_IDS.has(entityId) ||
    bizId === PRE_FIREBASE_TEST_BUSINESS_ID ||
    shopId === PRE_FIREBASE_TEST_SHOP_ID ||
    PRE_FIREBASE_BIZ_REGEX.test(bizId) ||
    PRE_FIREBASE_SHOP_REGEX.test(shopId)
  ) {
    return {
      blocked: true,
      reason: `QUARANTINE_ENFORCED: Refusing to synchronize pre-Firebase test record (${opId || entityId} under ${bizId}/${shopId}). Reason: ${PRE_FIREBASE_QUARANTINE_REASON}.`,
    };
  }

  if (KNOWN_DEMO_BUSINESS_IDS.has(bizId) || KNOWN_DEMO_SHOP_IDS.has(shopId)) {
    return {
      blocked: true,
      reason: `DEMO_ISOLATION_ENFORCED: Refusing to synchronize demo-mode record (${opId || entityId} under ${bizId}/${shopId}) to production Firestore.`,
    };
  }

  return { blocked: false };
}

function assertVerifiedAuthContext(
  auth: CallableAuthContext | null | undefined
): CallableAuthContext {
  if (!auth || !isValidEntityId(auth.uid)) {
    throw new Error('UNAUTHENTICATED: A valid Firebase Authentication session is required.');
  }
  if (auth.token?.email_verified !== true) {
    throw new Error(
      'PERMISSION_DENIED: Verified email address (email_verified == true) is required.'
    );
  }
  return auth;
}

async function assertCallerIsActivePlatformAdmin(
  tx: ServerTransactionContext,
  auth: CallableAuthContext
): Promise<Record<string, any>> {
  const callerProfile = await tx.getDoc(`users/${auth.uid}`);
  const callerEmail = (auth.token?.email || '').trim().toLowerCase();

  if (!callerEmail || callerEmail !== BOOTSTRAP_PLATFORM_ADMIN_EMAIL) {
    throw new Error(
      `PERMISSION_DENIED: Email "${callerEmail || 'unknown'}" is not authorized as the Platform Administrator.`
    );
  }

  if (!callerProfile) {
    throw new Error(
      `PERMISSION_DENIED: Platform Administrator profile at /users/${auth.uid} has not been initialized. Verified email alone does not grant administrator privileges without an active administrator profile.`
    );
  }

  if (callerProfile.status !== 'active') {
    throw new Error('PERMISSION_DENIED: Caller user profile is suspended.');
  }

  if (callerProfile.role !== 'platform_admin') {
    throw new Error(
      `PERMISSION_DENIED: Role "${callerProfile.role}" is not authorized to perform Platform Administrator operations.`
    );
  }

  const profileEmail = String(callerProfile.email || '')
    .trim()
    .toLowerCase();
  if (
    callerProfile.id !== auth.uid ||
    profileEmail !== BOOTSTRAP_PLATFORM_ADMIN_EMAIL
  ) {
    throw new Error(
      'PERMISSION_DENIED: Caller profile identity does not match the verified Platform Administrator account.'
    );
  }

  return callerProfile;
}

// ============================================================================
// 1. PRIVILEGED BUSINESS, FIRST SHOP & PRIMARY OWNER PROVISIONING
// ============================================================================

export async function executeProvisionBusinessAndPrimaryOwner(
  dbDriver: ServerDatabaseDriver,
  authDirectory: ServerAuthDirectory | null,
  auth: CallableAuthContext | null | undefined,
  input: ProvisionBusinessRequest
): Promise<ProvisionBusinessResponse> {
  if (dbDriver.databaseId !== NAMED_FIRESTORE_DATABASE_ID) {
    throw new Error(
      `DATABASE_CONFIG_MISMATCH: Expected named Firestore database "${NAMED_FIRESTORE_DATABASE_ID}", but driver is bound to "${dbDriver.databaseId}".`
    );
  }

  const verifiedAuth = assertVerifiedAuthContext(auth);

  if (!input || !isValidEntityId(input.idempotencyKey)) {
    throw new Error(
      'INVALID_ARGUMENT: A valid idempotencyKey (1-128 alphanumeric/hyphen characters) is required.'
    );
  }

  const cleanBusinessName = (input.name || '').trim();
  const cleanBusinessType = (input.businessType || '').trim();
  const cleanOwnerName = (input.ownerName || '').trim();
  const cleanOwnerEmail = (input.ownerEmail || '').trim().toLowerCase();
  const cleanContactEmail = (input.contactEmail || cleanOwnerEmail).trim().toLowerCase();
  const cleanPhone = (input.primaryPhone || '').trim();
  const cleanAddress = (input.headquartersAddress || '').trim();

  if (cleanBusinessName.length < 2 || cleanBusinessName.length > 140) {
    throw new Error('INVALID_ARGUMENT: Business name must be between 2 and 140 characters.');
  }
  if (cleanOwnerName.length < 2 || cleanOwnerName.length > 120) {
    throw new Error('INVALID_ARGUMENT: Primary owner name must be between 2 and 120 characters.');
  }
  if (!isValidEmailAddress(cleanOwnerEmail)) {
    throw new Error('INVALID_ARGUMENT: A valid primary owner email address is required.');
  }
  if (!isValidEmailAddress(cleanContactEmail)) {
    throw new Error('INVALID_ARGUMENT: A valid business contact email address is required.');
  }
  if (cleanPhone.length < 3 || cleanPhone.length > 40) {
    throw new Error('INVALID_ARGUMENT: A valid primary phone number is required.');
  }
  if (cleanAddress.length < 3 || cleanAddress.length > 250) {
    throw new Error('INVALID_ARGUMENT: A valid headquarters address is required.');
  }

  // Resolve owner account safely via Firebase Admin Auth before entering Firestore transaction
  const clientSuppliedOwnerUid = input.ownerUid?.trim() || undefined;
  if (clientSuppliedOwnerUid && !isValidEntityId(clientSuppliedOwnerUid)) {
    throw new Error('INVALID_ARGUMENT: Provided ownerUid has an invalid format.');
  }

  let authResolvedOwnerUid: string | null = null;
  if (authDirectory) {
    const byEmail = await authDirectory.getUserByEmail(cleanOwnerEmail);
    if (byEmail) {
      authResolvedOwnerUid = byEmail.uid;
      if (clientSuppliedOwnerUid && clientSuppliedOwnerUid !== byEmail.uid) {
        throw new Error(
          `PERMISSION_DENIED: Client-supplied ownerUid "${clientSuppliedOwnerUid}" does not match the authenticated Firebase user UID for "${cleanOwnerEmail}".`
        );
      }
    } else if (clientSuppliedOwnerUid) {
      const byUid = await authDirectory.getUserByUid(clientSuppliedOwnerUid);
      if (byUid && byUid.email.trim().toLowerCase() !== cleanOwnerEmail) {
        throw new Error(
          `PERMISSION_DENIED: Client-supplied ownerUid "${clientSuppliedOwnerUid}" belongs to a different email address in Firebase Auth.`
        );
      }
    }
  }

  return await dbDriver.runTransaction(async (tx) => {
    // 1. Authenticate and authorize Platform Administrator on the server
    const callerAdmin = await assertCallerIsActivePlatformAdmin(tx, verifiedAuth);
    const callerEmail = (
      callerAdmin.email ||
      verifiedAuth.token?.email ||
      ''
    )
      .trim()
      .toLowerCase();

    // 2. Enforce Platform Administrator separation from tenant ownership
    if (
      cleanOwnerEmail === callerEmail ||
      cleanOwnerEmail === BOOTSTRAP_PLATFORM_ADMIN_EMAIL ||
      clientSuppliedOwnerUid === verifiedAuth.uid ||
      authResolvedOwnerUid === verifiedAuth.uid
    ) {
      throw new Error(
        'PERMISSION_DENIED: Platform Administrator must remain separate from tenant ownership and cannot be provisioned as a Business Owner.'
      );
    }

    // 3. Check idempotency ledger first to avoid duplicate creation on retries
    const idempotencyDocPath = `platform_provisioning_keys/${input.idempotencyKey}`;
    const existingIdempotencyDoc = await tx.getDoc(idempotencyDocPath);
    if (existingIdempotencyDoc) {
      const existingBiz = await tx.getDoc(
        `businesses/${existingIdempotencyDoc.businessId}`
      );
      const existingOwner = await tx.getDoc(
        `users/${existingIdempotencyDoc.ownerUserId}`
      );
      const existingShop = await tx.getDoc(
        `businesses/${existingIdempotencyDoc.businessId}/shops/${existingIdempotencyDoc.firstShopId}`
      );
      if (existingBiz && existingOwner && existingShop) {
        return {
          status: 'idempotent_replay',
          isIdempotentReplay: true,
          databaseId: dbDriver.databaseId,
          business: existingBiz,
          primaryOwner: existingOwner,
          firstShop: existingShop,
        };
      }
    }

    // 4. Verify no existing user profile with cleanOwnerEmail belongs to another tenant or is platform_admin
    const existingProfilesByEmail = await tx.queryDocsByField(
      'users',
      'email',
      cleanOwnerEmail
    );
    if (existingProfilesByEmail.length > 0) {
      const existingProfile = existingProfilesByEmail[0];
      if (existingProfile.role === 'platform_admin') {
        throw new Error(
          'PERMISSION_DENIED: Cannot assign a Platform Administrator account as a tenant Business Owner.'
        );
      }
      throw new Error(
        `ALREADY_EXISTS: Email "${cleanOwnerEmail}" is already bound to an active user profile in business "${existingProfile.businessId}".`
      );
    }

    // 5. Determine canonical ownerUserId safely
    const finalOwnerUid =
      authResolvedOwnerUid ||
      clientSuppliedOwnerUid ||
      `usr-live-owner-${input.idempotencyKey.replace(/[^a-zA-Z0-9]/g, '').slice(-12)}`;

    const existingOwnerDocById = await tx.getDoc(`users/${finalOwnerUid}`);
    if (existingOwnerDocById) {
      const existingDocEmail = String(existingOwnerDocById.email || '')
        .trim()
        .toLowerCase();
      if (existingDocEmail !== cleanOwnerEmail) {
        throw new Error(
          `PERMISSION_DENIED: Target owner UID "${finalOwnerUid}" is already bound to a different user account.`
        );
      }
      if (existingOwnerDocById.role === 'platform_admin') {
        throw new Error(
          'PERMISSION_DENIED: Target UID belongs to a Platform Administrator.'
        );
      }
      throw new Error(
        `ALREADY_EXISTS: Target owner UID "${finalOwnerUid}" is already assigned to business "${existingOwnerDocById.businessId}".`
      );
    }

    // 6. Determine and validate businessId and firstShopId
    const businessId =
      input.businessId && isValidEntityId(input.businessId)
        ? input.businessId
        : `biz-live-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    if (
      KNOWN_DEMO_BUSINESS_IDS.has(businessId) ||
      VALID_PLATFORM_ADMIN_SENTINELS.has(businessId) ||
      businessId === PRE_FIREBASE_TEST_BUSINESS_ID ||
      PRE_FIREBASE_BIZ_REGEX.test(businessId)
    ) {
      throw new Error(
        `INVALID_ARGUMENT: Business ID "${businessId}" is reserved or quarantined.`
      );
    }

    const existingBizDoc = await tx.getDoc(`businesses/${businessId}`);
    if (existingBizDoc) {
      throw new Error(`ALREADY_EXISTS: Business "${businessId}" already exists.`);
    }

    const prefix =
      cleanBusinessName
        .split(/\s+/)
        .map((w) => w[0] || '')
        .join('')
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, '')
        .slice(0, 3) || 'SHP';

    const firstShopId =
      input.initialShopId && isValidEntityId(input.initialShopId)
        ? input.initialShopId
        : `shop-live-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    const firstShopCode = (input.initialShopCode || `${prefix}-01`)
      .trim()
      .toUpperCase()
      .slice(0, 30);
    const firstShopName = (
      input.initialShopName || `${cleanBusinessName} — Main Branch`
    )
      .trim()
      .slice(0, 140);
    const firstShopCategory = (input.initialShopCategory || 'Supermarket')
      .trim()
      .slice(0, 80);
    const firstShopCity = (input.initialShopCity || 'Lagos').trim().slice(0, 80);
    const firstShopAddress = (input.initialShopAddress || cleanAddress)
      .trim()
      .slice(0, 240);
    const firstShopPhone = (input.initialShopPhone || cleanPhone)
      .trim()
      .slice(0, 40);

    const nowIso = new Date().toISOString();
    const taxRate =
      typeof input.defaultTaxRatePercent === 'number' &&
      input.defaultTaxRatePercent >= 0 &&
      input.defaultTaxRatePercent <= 100
        ? input.defaultTaxRatePercent
        : 7.5;

    const businessDoc: Record<string, any> = {
      id: businessId,
      name: cleanBusinessName,
      legalName: (input.legalName || `${cleanBusinessName} Ltd`).trim().slice(0, 180),
      businessType: cleanBusinessType.slice(0, 100),
      registrationNumber: (
        input.registrationNumber || `RC-${Date.now().toString().slice(-7)}`
      )
        .trim()
        .slice(0, 60),
      taxIdentificationNumber: (
        input.taxIdentificationNumber || `TIN-${Date.now().toString().slice(-8)}`
      )
        .trim()
        .slice(0, 60),
      ownerUserId: finalOwnerUid,
      ownerName: cleanOwnerName,
      ownerEmail: cleanOwnerEmail,
      contactEmail: cleanContactEmail,
      primaryPhone: cleanPhone,
      headquartersAddress: cleanAddress,
      currencyCode: (input.currencyCode || 'NGN').trim().slice(0, 3),
      currencySymbol: (input.currencySymbol || '₦').trim().slice(0, 5),
      defaultTaxRatePercent: taxRate,
      status: 'active',
      ...(input.notes ? { notes: input.notes.trim().slice(0, 500) } : {}),
      schemaVersion: 6,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const firstShopDoc: Record<string, any> = {
      id: firstShopId,
      businessId,
      code: firstShopCode,
      name: firstShopName,
      category: firstShopCategory,
      locationCity: firstShopCity,
      address: firstShopAddress,
      phone: firstShopPhone,
      managerName: cleanOwnerName,
      status: 'active',
      terminalId: `TERM-${firstShopCode.replace(/[^A-Z0-9]/g, '')}`,
      taxRatePercent: taxRate,
      receiptHeaderNote: `${firstShopName} — Official Receipt`,
      receiptFooterNote: 'Thank you for your patronage',
      schemaVersion: 6,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    // Primary owner role is strictly locked to 'business_owner'
    const primaryOwnerDoc: Record<string, any> = {
      id: finalOwnerUid,
      businessId,
      username: cleanOwnerEmail.split('@')[0].slice(0, 80) || finalOwnerUid,
      email: cleanOwnerEmail,
      fullName: cleanOwnerName,
      role: 'business_owner',
      roleLabel: `Business Owner (${cleanBusinessName})`.slice(0, 100),
      assignedShopIds: [firstShopId],
      permissions: [...DEFAULT_BUSINESS_OWNER_PERMISSIONS],
      status: 'active',
      schemaVersion: 6,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const idempotencyRecord: Record<string, any> = {
      id: input.idempotencyKey,
      businessId,
      ownerUserId: finalOwnerUid,
      ownerEmail: cleanOwnerEmail,
      firstShopId,
      provisionedByUid: verifiedAuth.uid,
      schemaVersion: 6,
      createdAt: nowIso,
    };

    const auditEventId = `aud-prov-${input.idempotencyKey}`;
    const auditEventDoc: Record<string, any> = {
      id: auditEventId,
      businessId,
      shopId: firstShopId,
      userId: verifiedAuth.uid,
      userName: String(callerAdmin.fullName || 'Platform Administrator').slice(0, 120),
      action: 'business_and_primary_owner_provisioned',
      entityType: 'business',
      entityId: businessId,
      detailsJson: JSON.stringify({
        businessId,
        businessName: cleanBusinessName,
        ownerUserId: finalOwnerUid,
        firstShopId,
        idempotencyKey: input.idempotencyKey,
      }),
      createdAt: nowIso,
    };

    // 7. Commit all 5 documents atomically in the transaction
    tx.setDoc(`businesses/${businessId}`, businessDoc);
    tx.setDoc(`businesses/${businessId}/shops/${firstShopId}`, firstShopDoc);
    tx.setDoc(`users/${finalOwnerUid}`, primaryOwnerDoc);
    tx.setDoc(idempotencyDocPath, idempotencyRecord);
    tx.setDoc(`businesses/${businessId}/audit_events/${auditEventId}`, auditEventDoc);

    return {
      status: 'provisioned',
      isIdempotentReplay: false,
      databaseId: dbDriver.databaseId,
      business: businessDoc,
      primaryOwner: primaryOwnerDoc,
      firstShop: firstShopDoc,
    };
  });
}

// ============================================================================
// 2. PRIVILEGED POS TRANSACTION SYNCHRONIZATION (syncPosOperation)
// ============================================================================

export async function executeSyncPosOperation(
  dbDriver: ServerDatabaseDriver,
  auth: CallableAuthContext | null | undefined,
  req: SyncOperationPayload
): Promise<SyncOperationResponse> {
  if (dbDriver.databaseId !== NAMED_FIRESTORE_DATABASE_ID) {
    throw new Error(
      `DATABASE_CONFIG_MISMATCH: Expected named Firestore database "${NAMED_FIRESTORE_DATABASE_ID}", but driver is bound to "${dbDriver.databaseId}".`
    );
  }

  const verifiedAuth = assertVerifiedAuthContext(auth);

  if (
    !req ||
    !isValidEntityId(req.operationId) ||
    !isValidEntityId(req.idempotencyKey) ||
    !isValidEntityId(req.businessId) ||
    !isValidEntityId(req.shopId) ||
    !isValidEntityId(req.entityId)
  ) {
    return {
      outcome: 'rejected_unauthorized',
      status: 'failed',
      databaseId: dbDriver.databaseId,
      errorMessage:
        'INVALID_ARGUMENT: operationId, idempotencyKey, businessId, shopId, and entityId must be valid identifiers.',
    };
  }

  // STEP 0: Hard Quarantine & Demo Guard — never allow quarantined or pre-Firebase test sales into Firestore
  const quarantineCheck = isQuarantinedOrDemoOperation({
    operationId: req.operationId,
    entityId: req.entityId,
    businessId: req.businessId,
    shopId: req.shopId,
    status: req.status,
  });
  if (quarantineCheck.blocked) {
    return {
      outcome: 'rejected_unauthorized',
      status: 'failed',
      databaseId: dbDriver.databaseId,
      errorMessage: quarantineCheck.reason,
    };
  }

  return await dbDriver.runTransaction(async (tx) => {
    // STEP 1: Verify caller identity, role, business membership, and shop assignment from trusted Firestore records.
    // Client-supplied role claims (`req.clientClaimedRole`) are completely ignored.
    const callerProfile = await tx.getDoc(`users/${verifiedAuth.uid}`);
    if (!callerProfile) {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: 'UNAUTHORIZED: Authenticated user profile does not exist in Firestore.',
      };
    }

    if (callerProfile.status !== 'active') {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: 'FORBIDDEN: Authenticated user account is suspended.',
      };
    }

    // Platform Administrator is strictly separated from tenant operational data
    if (callerProfile.role === 'platform_admin') {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage:
          'FORBIDDEN_ROLE_BOUNDARY: Platform Administrator does not have access to tenant shop sales, stock, or synchronization.',
      };
    }

    if (callerProfile.businessId !== req.businessId) {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: `FORBIDDEN_CROSS_BUSINESS: User belongs to "${callerProfile.businessId}" and cannot synchronize data for business "${req.businessId}".`,
      };
    }

    const businessDoc = await tx.getDoc(`businesses/${req.businessId}`);
    if (!businessDoc || businessDoc.status !== 'active') {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: `FORBIDDEN_TENANT_INACTIVE: Business "${req.businessId}" does not exist or is suspended.`,
      };
    }

    const shopDoc = await tx.getDoc(
      `businesses/${req.businessId}/shops/${req.shopId}`
    );
    if (!shopDoc || shopDoc.businessId !== req.businessId) {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: `FORBIDDEN_SHOP_MISMATCH: Shop "${req.shopId}" does not exist under business "${req.businessId}".`,
      };
    }

    const assignedShops = Array.isArray(callerProfile.assignedShopIds)
      ? callerProfile.assignedShopIds
      : [];
    if (
      callerProfile.role !== 'business_owner' &&
      !assignedShops.includes(req.shopId)
    ) {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage: `FORBIDDEN_UNASSIGNED_SHOP: User (${callerProfile.role}) is not assigned to shop "${req.shopId}".`,
      };
    }

    if (req.entityType !== 'sale' && callerProfile.role === 'cashier') {
      return {
        outcome: 'rejected_unauthorized',
        status: 'failed',
        databaseId: dbDriver.databaseId,
        errorMessage:
          'FORBIDDEN_INSUFFICIENT_ROLE: Cashiers are only authorized to synchronize POS sales.',
      };
    }

    // STEP 2: Idempotency check — prevent duplicate sale creation or double stock deduction
    const syncOpPath = `businesses/${req.businessId}/shops/${req.shopId}/sync_operations/${req.idempotencyKey}`;
    const existingSyncOp = await tx.getDoc(syncOpPath);
    if (existingSyncOp) {
      if (existingSyncOp.outcome === 'acknowledged') {
        return {
          outcome: 'acknowledged',
          status: 'synced',
          databaseId: dbDriver.databaseId,
          ackId: existingSyncOp.ackId || `ack-${req.idempotencyKey}`,
          syncedAt: existingSyncOp.processedAt,
          isDuplicateReplay: true,
        };
      }
      return {
        outcome: existingSyncOp.outcome,
        status:
          existingSyncOp.outcome === 'conflict_requires_review'
            ? 'requires_review'
            : 'failed',
        databaseId: dbDriver.databaseId,
        conflictReason: existingSyncOp.conflictReason,
        isDuplicateReplay: true,
      };
    }

    const nowIso = new Date().toISOString();

    // STEP 3: Sale Creation with Granular Permission, Identity, Arithmetic Validation & Atomic Stock Deduction
    if (req.entityType === 'sale' && req.operationType === 'create') {
      if (
        !callerHasPermission(callerProfile, [
          'process_sales',
          'process_sale',
          'pos_checkout',
        ])
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_MISSING_PERMISSION: Caller does not have permission (process_sales) to synchronize POS sales.',
        };
      }

      const sale = req.payload?.sale;
      const items = Array.isArray(req.payload?.items) ? req.payload.items : [];
      const payment = req.payload?.payment;

      if (!sale || items.length === 0) {
        return {
          outcome: 'conflict_requires_review',
          status: 'requires_review',
          databaseId: dbDriver.databaseId,
          conflictReason: 'Malformed sale sync payload: missing sale header or line items.',
        };
      }

      if (
        sale.business_id !== req.businessId ||
        sale.shop_id !== req.shopId ||
        sale.id !== req.entityId
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_PAYLOAD_SCOPE_MISMATCH: Sale payload identifiers do not match request scope.',
        };
      }

      // SEC-02: Enforce valid initial sale status ('completed') on creation
      if (sale.status !== 'completed') {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_INVALID_INITIAL_SALE_STATUS: Newly synchronized sales must have status "completed".',
        };
      }

      // SEC-02: Prevent cashier identity spoofing (must match caller UID unless Business Owner syncing shop queue)
      if (
        callerProfile.role !== 'business_owner' &&
        sale.cashier_user_id !== verifiedAuth.uid
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_CASHIER_IDENTITY_MISMATCH: Operator cannot synchronize a sale attributed to a different cashierUserId.',
        };
      }

      // SEC-06: Require discount permission when sale carries a non-zero discount
      if (
        Number(sale.discount_amount_kobo || 0) > 0 &&
        !callerHasPermission(callerProfile, [
          'apply_discounts',
          'apply_discount',
        ])
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_MISSING_PERMISSION: Caller does not have permission (apply_discounts) to apply sale discounts.',
        };
      }

      // Check if sale document already exists under entityId (secondary idempotency guard)
      const saleDocPath = `businesses/${req.businessId}/shops/${req.shopId}/sales/${sale.id}`;
      const existingSaleDoc = await tx.getDoc(saleDocPath);
      if (existingSaleDoc) {
        const ackId = existingSaleDoc.syncAckId || `ack-${req.idempotencyKey}`;
        return {
          outcome: 'acknowledged',
          status: 'synced',
          databaseId: dbDriver.databaseId,
          ackId,
          syncedAt: existingSaleDoc.syncedAt || nowIso,
          isDuplicateReplay: true,
        };
      }

      // Validate line item quantities and monetary totals
      let computedSubtotalKobo = 0;
      for (const line of items) {
        if (
          !line ||
          !isValidEntityId(line.product_id) ||
          !Number.isInteger(line.quantity) ||
          line.quantity <= 0 ||
          !Number.isInteger(line.unit_price_kobo) ||
          line.unit_price_kobo < 0 ||
          !Number.isInteger(line.line_total_kobo) ||
          line.line_total_kobo !== line.unit_price_kobo * line.quantity
        ) {
          const reason = `Invalid line item math or quantity for product "${line?.product_name || line?.product_id}".`;
          return recordSyncConflictInTransaction(
            tx,
            dbDriver.databaseId,
            req,
            verifiedAuth.uid,
            String(callerProfile.fullName || 'Operator'),
            reason,
            nowIso
          );
        }
        computedSubtotalKobo += line.line_total_kobo;
      }

      const expectedTotalKobo =
        computedSubtotalKobo -
        Number(sale.discount_amount_kobo || 0) +
        Number(sale.tax_amount_kobo || 0);

      if (
        sale.subtotal_kobo !== computedSubtotalKobo ||
        sale.total_amount_kobo !== expectedTotalKobo ||
        sale.total_amount_kobo < 0 ||
        sale.discount_amount_kobo < 0 ||
        sale.tax_amount_kobo < 0
      ) {
        const reason = `Sale monetary total mismatch: expected subtotal=${computedSubtotalKobo}, total=${expectedTotalKobo}, received subtotal=${sale.subtotal_kobo}, total=${sale.total_amount_kobo}.`;
        return recordSyncConflictInTransaction(
          tx,
          dbDriver.databaseId,
          req,
          verifiedAuth.uid,
          String(callerProfile.fullName || 'Operator'),
          reason,
          nowIso
        );
      }

      // SEC-02: Enforce tender and change due arithmetic
      const isValidTenderChange =
        sale.payment_method === 'credit' ||
        (Number.isInteger(sale.amount_tendered_kobo) &&
          Number.isInteger(sale.change_due_kobo) &&
          sale.amount_tendered_kobo >= sale.total_amount_kobo &&
          sale.change_due_kobo ===
            sale.amount_tendered_kobo - sale.total_amount_kobo);

      if (!isValidTenderChange) {
        const reason = `Sale tender/change arithmetic mismatch: total=${sale.total_amount_kobo}, tendered=${sale.amount_tendered_kobo}, changeDue=${sale.change_due_kobo}.`;
        return recordSyncConflictInTransaction(
          tx,
          dbDriver.databaseId,
          req,
          verifiedAuth.uid,
          String(callerProfile.fullName || 'Operator'),
          reason,
          nowIso
        );
      }

      // Validate current cloud stock for every line item BEFORE deducting anything
      const productDocsToUpdate: Array<{
        path: string;
        doc: Record<string, any>;
        line: SyncPosSaleItemPayload;
        previousQty: number;
        newQty: number;
      }> = [];

      for (const line of items) {
        const productPath = `businesses/${req.businessId}/shops/${req.shopId}/products/${line.product_id}`;
        const productDoc = await tx.getDoc(productPath);

        if (!productDoc || productDoc.shopId !== req.shopId || productDoc.businessId !== req.businessId) {
          const reason = `Product "${line.product_name}" (${line.sku}) not found in shop "${req.shopId}" cloud catalogue.`;
          return recordSyncConflictInTransaction(
            tx,
            dbDriver.databaseId,
            req,
            verifiedAuth.uid,
            String(callerProfile.fullName || 'Operator'),
            reason,
            nowIso
          );
        }

        const currentStock = Number(productDoc.stockQuantity ?? 0);
        if (currentStock < line.quantity) {
          const reason = `Stock conflict for "${productDoc.name}" (${productDoc.sku}): cloud stock is ${currentStock}, offline sale requested ${line.quantity}. Completed local sale preserved for manager review.`;
          return recordSyncConflictInTransaction(
            tx,
            dbDriver.databaseId,
            req,
            verifiedAuth.uid,
            String(callerProfile.fullName || 'Operator'),
            reason,
            nowIso
          );
        }

        productDocsToUpdate.push({
          path: productPath,
          doc: productDoc,
          line,
          previousQty: currentStock,
          newQty: currentStock - line.quantity,
        });
      }

      // All stock checks passed — atomically deduct stock, record inventory movements, sale, payment, sync op, and audit event
      for (const itemUpdate of productDocsToUpdate) {
        tx.setDoc(itemUpdate.path, {
          ...itemUpdate.doc,
          stockQuantity: itemUpdate.newQty,
          updatedAt: nowIso,
        });

        const movementId = `mov-${sale.id}-${itemUpdate.line.product_id}`;
        tx.setDoc(
          `businesses/${req.businessId}/shops/${req.shopId}/inventory_movements/${movementId}`,
          {
            id: movementId,
            shopId: req.shopId,
            businessId: req.businessId,
            productId: itemUpdate.line.product_id,
            productName: itemUpdate.line.product_name,
            productSku: itemUpdate.line.sku,
            type: 'sale_deduction',
            quantityDelta: -itemUpdate.line.quantity,
            previousQuantity: itemUpdate.previousQty,
            newQuantity: itemUpdate.newQty,
            reason: `Cloud Synced Sale ${sale.receipt_number}`,
            referenceId: sale.id,
            performedByUserId: verifiedAuth.uid,
            performedByName: String(callerProfile.fullName || sale.cashier_name),
            schemaVersion: 6,
            createdAt: nowIso,
          }
        );
      }

      const ackId = `ack-${req.idempotencyKey}-${Date.now()}`;
      const firestoreSaleDoc: Record<string, any> = {
        id: sale.id,
        shopId: req.shopId,
        businessId: req.businessId,
        receiptNumber: sale.receipt_number,
        terminalId: sale.terminal_id,
        cashierUserId: sale.cashier_user_id,
        cashierName: sale.cashier_name,
        subtotalKobo: sale.subtotal_kobo,
        discountAmountKobo: sale.discount_amount_kobo,
        taxRatePercent: sale.tax_rate_percent,
        taxAmountKobo: sale.tax_amount_kobo,
        totalAmountKobo: sale.total_amount_kobo,
        amountTenderedKobo: sale.amount_tendered_kobo,
        changeDueKobo: sale.change_due_kobo,
        paymentMethod: sale.payment_method,
        status: 'completed',
        idempotencyKey: req.idempotencyKey,
        syncAckId: ackId,
        schemaVersion: 6,
        createdAt: sale.created_at,
        syncedAt: nowIso,
      };
      tx.setDoc(saleDocPath, firestoreSaleDoc);

      for (let i = 0; i < items.length; i += 1) {
        const line = items[i];
        const lineId = isValidEntityId(line.id)
          ? line.id
          : `line-${sale.id}-${i + 1}`;
        tx.setDoc(`${saleDocPath}/items/${lineId}`, {
          id: lineId,
          saleId: sale.id,
          shopId: req.shopId,
          businessId: req.businessId,
          productId: line.product_id,
          sku: line.sku,
          barcode: line.barcode || line.sku,
          productName: line.product_name,
          unit: line.unit || 'Unit',
          unitPriceKobo: line.unit_price_kobo,
          costPriceKobo: line.cost_price_kobo,
          quantity: line.quantity,
          lineTotalKobo: line.line_total_kobo,
          schemaVersion: 6,
          createdAt: sale.created_at || nowIso,
        });
      }

      const paymentId =
        payment && isValidEntityId(payment.id) ? payment.id : `pay-${sale.id}`;
      tx.setDoc(
        `businesses/${req.businessId}/shops/${req.shopId}/payments/${paymentId}`,
        {
          id: paymentId,
          shopId: req.shopId,
          businessId: req.businessId,
          referenceType: 'sale',
          referenceId: sale.id,
          amountKobo: sale.total_amount_kobo,
          paymentMethod: sale.payment_method,
          recordedByUserId: verifiedAuth.uid,
          recordedByName: String(callerProfile.fullName || sale.cashier_name),
          schemaVersion: 6,
          createdAt: nowIso,
        }
      );

      tx.setDoc(syncOpPath, {
        id: req.idempotencyKey,
        businessId: req.businessId,
        shopId: req.shopId,
        entityType: 'sale',
        entityId: sale.id,
        operationType: 'create',
        actorUserId: verifiedAuth.uid,
        outcome: 'acknowledged',
        ackId,
        schemaVersion: req.schemaVersion || 6,
        processedAt: nowIso,
      });

      const auditId = `aud-sync-${req.idempotencyKey}`;
      tx.setDoc(`businesses/${req.businessId}/audit_events/${auditId}`, {
        id: auditId,
        businessId: req.businessId,
        shopId: req.shopId,
        userId: verifiedAuth.uid,
        userName: String(callerProfile.fullName || sale.cashier_name).slice(0, 120),
        action: 'cloud_sale_synced',
        entityType: 'sale',
        entityId: sale.id,
        detailsJson: JSON.stringify({
          receiptNumber: sale.receipt_number,
          totalAmountKobo: sale.total_amount_kobo,
          idempotencyKey: req.idempotencyKey,
          ackId,
        }),
        createdAt: nowIso,
      });

      return {
        outcome: 'acknowledged',
        status: 'synced',
        databaseId: dbDriver.databaseId,
        ackId,
        syncedAt: nowIso,
        isDuplicateReplay: false,
      };
    }

    // STEP 4: Authorized Shop Catalogue Product Synchronization (SEC-06 & SEC-10)
    if (
      req.entityType === 'product' &&
      (req.operationType === 'create' || req.operationType === 'update')
    ) {
      if (
        !callerHasPermission(callerProfile, [
          'manage_products',
          'manage_catalogue',
          'manage_inventory',
        ])
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_MISSING_PERMISSION: Caller does not have permission (manage_products) to synchronize shop catalogue products.',
        };
      }

      const prod = req.payload?.product;
      if (
        !prod ||
        typeof prod !== 'object' ||
        (prod.id && prod.id !== req.entityId) ||
        (prod.business_id && prod.business_id !== req.businessId) ||
        (prod.businessId && prod.businessId !== req.businessId) ||
        (prod.shop_id && prod.shop_id !== req.shopId) ||
        (prod.shopId && prod.shopId !== req.shopId)
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'UNSUPPORTED_SYNC_OPERATION: Product synchronization requires a valid product payload matching the target businessId, shopId, and entityId.',
        };
      }

      const productPath = `businesses/${req.businessId}/shops/${req.shopId}/products/${req.entityId}`;
      const existingProduct = await tx.getDoc(productPath);
      tx.setDoc(productPath, {
        ...(existingProduct || {}),
        ...prod,
        id: req.entityId,
        businessId: req.businessId,
        shopId: req.shopId,
        updatedAt: nowIso,
      });

      const ackId = `ack-${req.idempotencyKey}-${Date.now()}`;
      tx.setDoc(syncOpPath, {
        id: req.idempotencyKey,
        businessId: req.businessId,
        shopId: req.shopId,
        entityType: 'product',
        entityId: req.entityId,
        operationType: req.operationType,
        actorUserId: verifiedAuth.uid,
        outcome: 'acknowledged',
        ackId,
        schemaVersion: req.schemaVersion || 6,
        processedAt: nowIso,
      });

      return {
        outcome: 'acknowledged',
        status: 'synced',
        databaseId: dbDriver.databaseId,
        ackId,
        syncedAt: nowIso,
        isDuplicateReplay: false,
      };
    }

    // STEP 5: Authorized Inventory Movement Synchronization (SEC-06 & SEC-10)
    if (
      req.entityType === 'inventory_movement' &&
      (req.operationType === 'create' || req.operationType === 'adjust')
    ) {
      if (
        !callerHasPermission(callerProfile, [
          'adjust_inventory',
          'adjust_stock',
        ])
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'FORBIDDEN_MISSING_PERMISSION: Caller does not have permission (adjust_inventory) to synchronize stock adjustments.',
        };
      }

      const mov = req.payload?.movement;
      if (
        !mov ||
        typeof mov !== 'object' ||
        (mov.id && mov.id !== req.entityId) ||
        (mov.business_id && mov.business_id !== req.businessId) ||
        (mov.businessId && mov.businessId !== req.businessId) ||
        (mov.shop_id && mov.shop_id !== req.shopId) ||
        (mov.shopId && mov.shopId !== req.shopId)
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage:
            'UNSUPPORTED_SYNC_OPERATION: Inventory movement synchronization requires a valid movement payload matching the target businessId, shopId, and entityId.',
        };
      }

      const allowedMovementTypes = new Set([
        'restock',
        'add_stock',
        'damage_spoilage',
        'return_in',
        'audit_correction',
        'sale_deduction',
      ]);
      const quantityDelta = Number(mov.quantity_delta ?? mov.quantityDelta);
      const movementType = String(mov.type || '');
      const productId = String(mov.product_id || mov.productId || '');
      if (
        !productId ||
        !allowedMovementTypes.has(movementType) ||
        !Number.isSafeInteger(quantityDelta) ||
        quantityDelta === 0
      ) {
        return {
          outcome: 'rejected_unauthorized',
          status: 'failed',
          databaseId: dbDriver.databaseId,
          errorMessage: 'INVALID_INVENTORY_MOVEMENT: A valid product, movement type, and non-zero integer quantity delta are required.',
        };
      }

      // Never trust the offline client's previous/new quantity snapshot. Apply its
      // signed delta to the current cloud quantity inside this same transaction.
      const productPath = `businesses/${req.businessId}/shops/${req.shopId}/products/${productId}`;
      const productDoc = await tx.getDoc(productPath);
      if (!productDoc) {
        return {
          outcome: 'conflict_requires_review',
          status: 'requires_review',
          databaseId: dbDriver.databaseId,
          conflictReason: `Product ${productId} no longer exists in the cloud shop.`,
        };
      }
      const currentCloudStock = Number(productDoc.stockQuantity);
      if (!Number.isSafeInteger(currentCloudStock) || currentCloudStock < 0) {
        return {
          outcome: 'conflict_requires_review',
          status: 'requires_review',
          databaseId: dbDriver.databaseId,
          conflictReason: `Cloud stock quantity for product ${productId} is invalid.`,
        };
      }
      const nextCloudStock = currentCloudStock + quantityDelta;
      if (!Number.isSafeInteger(nextCloudStock) || nextCloudStock < 0) {
        return {
          outcome: 'conflict_requires_review',
          status: 'requires_review',
          databaseId: dbDriver.databaseId,
          conflictReason: `Stock conflict for ${productId}: cloud quantity ${currentCloudStock}, requested adjustment ${quantityDelta}.`,
        };
      }

      tx.setDoc(productPath, {
        ...productDoc,
        stockQuantity: nextCloudStock,
        updatedAt: nowIso,
      });

      const movPath = `businesses/${req.businessId}/shops/${req.shopId}/inventory_movements/${req.entityId}`;
      tx.setDoc(movPath, {
        ...mov,
        id: req.entityId,
        businessId: req.businessId,
        shopId: req.shopId,
        productId,
        type: movementType,
        quantityDelta,
        previousQuantity: currentCloudStock,
        newQuantity: nextCloudStock,
        performedByUserId: verifiedAuth.uid,
        createdAt: mov.createdAt || mov.created_at || nowIso,
      });

      const ackId = `ack-${req.idempotencyKey}-${Date.now()}`;
      tx.setDoc(syncOpPath, {
        id: req.idempotencyKey,
        businessId: req.businessId,
        shopId: req.shopId,
        entityType: 'inventory_movement',
        entityId: req.entityId,
        operationType: req.operationType,
        actorUserId: verifiedAuth.uid,
        outcome: 'acknowledged',
        ackId,
        schemaVersion: req.schemaVersion || 6,
        processedAt: nowIso,
      });

      return {
        outcome: 'acknowledged',
        status: 'synced',
        databaseId: dbDriver.databaseId,
        ackId,
        syncedAt: nowIso,
        isDuplicateReplay: false,
      };
    }

    // SEC-10: Explicitly reject unsupported or unapplied sync operations instead of returning a misleading 'acknowledged' receipt
    return {
      outcome: 'rejected_unauthorized',
      status: 'failed',
      databaseId: dbDriver.databaseId,
      errorMessage: `UNSUPPORTED_SYNC_OPERATION: Operation "${req.entityType}:${req.operationType}" is not supported by syncPosOperation or is missing required verified entity payload.`,
    };
  });
}

function recordSyncConflictInTransaction(
  tx: ServerTransactionContext,
  databaseId: string,
  req: SyncOperationPayload,
  actorUserId: string,
  actorUserName: string,
  conflictReason: string,
  nowIso: string
): SyncOperationResponse {
  const syncOpPath = `businesses/${req.businessId}/shops/${req.shopId}/sync_operations/${req.idempotencyKey}`;
  tx.setDoc(syncOpPath, {
    id: req.idempotencyKey,
    businessId: req.businessId,
    shopId: req.shopId,
    entityType: req.entityType,
    entityId: req.entityId,
    operationType: req.operationType,
    actorUserId,
    outcome: 'conflict_requires_review',
    conflictReason: conflictReason.slice(0, 400),
    schemaVersion: req.schemaVersion || 6,
    processedAt: nowIso,
  });

  const auditId = `aud-conflict-${req.idempotencyKey}`;
  tx.setDoc(`businesses/${req.businessId}/audit_events/${auditId}`, {
    id: auditId,
    businessId: req.businessId,
    shopId: req.shopId,
    userId: actorUserId,
    userName: actorUserName.slice(0, 120),
    action: 'cloud_sync_stock_conflict',
    entityType: req.entityType,
    entityId: req.entityId,
    detailsJson: JSON.stringify({
      idempotencyKey: req.idempotencyKey,
      conflictReason,
    }),
    createdAt: nowIso,
  });

  return {
    outcome: 'conflict_requires_review',
    status: 'requires_review',
    databaseId,
    conflictReason,
    isDuplicateReplay: false,
  };
}

// ============================================================================
// 3. AUTHORIZED STAFF INVITATION & TENANT STATUS FUNCTIONS
// ============================================================================

export async function executeInviteAuthorizedStaff(
  dbDriver: ServerDatabaseDriver,
  auth: CallableAuthContext | null | undefined,
  input: InviteAuthorizedStaffRequest,
  authDirectory?: ServerAuthDirectory
): Promise<{
  status: 'created';
  isIdempotentReplay?: boolean;
  staffUser: Record<string, any>;
}> {
  if (dbDriver.databaseId !== NAMED_FIRESTORE_DATABASE_ID) {
    throw new Error(
      `DATABASE_CONFIG_MISMATCH: Expected named Firestore database "${NAMED_FIRESTORE_DATABASE_ID}", but driver is bound to "${dbDriver.databaseId}".`
    );
  }

  const verifiedAuth = assertVerifiedAuthContext(auth);

  if (!input || typeof input !== 'object' || !isValidEntityId(input.idempotencyKey)) {
    throw new Error(
      'INVALID_ARGUMENT: A valid idempotencyKey is required for staff invitation.'
    );
  }

  if (
    typeof input.businessId !== 'string' ||
    !isValidEntityId(input.businessId) ||
    KNOWN_DEMO_BUSINESS_IDS.has(input.businessId) ||
    VALID_PLATFORM_ADMIN_SENTINELS.has(input.businessId) ||
    input.businessId === PRE_FIREBASE_TEST_BUSINESS_ID ||
    PRE_FIREBASE_BIZ_REGEX.test(input.businessId)
  ) {
    throw new Error(
      `INVALID_ARGUMENT: Business ID "${String(input.businessId ?? '')}" is invalid, reserved, or quarantined.`
    );
  }

  if (
    typeof input.role !== 'string' ||
    ((input.role as string) !== 'shop_manager' && (input.role as string) !== 'cashier')
  ) {
    throw new Error(
      'PERMISSION_DENIED: Staff provisioning can only assign role "shop_manager" or "cashier" (never "business_owner" or "platform_admin").'
    );
  }

  if (typeof input.fullName !== 'string') {
    throw new Error(
      'INVALID_ARGUMENT: Staff fullName must be between 2 and 120 characters.'
    );
  }
  const cleanFullName = input.fullName.trim();
  if (cleanFullName.length < 2 || cleanFullName.length > 120) {
    throw new Error(
      'INVALID_ARGUMENT: Staff fullName must be between 2 and 120 characters.'
    );
  }

  if (typeof input.email !== 'string') {
    throw new Error('INVALID_ARGUMENT: A valid staff email address is required.');
  }
  const cleanEmail = input.email.trim().toLowerCase();
  if (!isValidEmailAddress(cleanEmail)) {
    throw new Error('INVALID_ARGUMENT: A valid staff email address is required.');
  }
  if (cleanEmail === BOOTSTRAP_PLATFORM_ADMIN_EMAIL) {
    throw new Error(
      `PERMISSION_DENIED: Platform Administrator identity (${BOOTSTRAP_PLATFORM_ADMIN_EMAIL}) cannot be invited as tenant staff.`
    );
  }

  if (
    !Array.isArray(input.assignedShopIds) ||
    input.assignedShopIds.length === 0 ||
    input.assignedShopIds.length > 50
  ) {
    throw new Error(
      'INVALID_ARGUMENT: assignedShopIds must be a non-empty array of between 1 and 50 shop IDs.'
    );
  }
  for (const shopId of input.assignedShopIds) {
    if (
      typeof shopId !== 'string' ||
      !isValidEntityId(shopId) ||
      KNOWN_DEMO_SHOP_IDS.has(shopId) ||
      shopId === PRE_FIREBASE_TEST_SHOP_ID ||
      PRE_FIREBASE_SHOP_REGEX.test(shopId)
    ) {
      throw new Error(
        `INVALID_ARGUMENT: Shop ID "${String(shopId)}" is invalid, reserved, or quarantined.`
      );
    }
  }
  const dedupedAssignedShopIds = Array.from(new Set(input.assignedShopIds));

  // Enforce strict role-specific permission allowlist at runtime
  const validatedPermissions = validateRoleSpecificStaffPermissions(
    input.role,
    input.permissions
  );

  if (input.staffUid !== undefined) {
    if (typeof input.staffUid !== 'string' || !isValidEntityId(input.staffUid)) {
      throw new Error('INVALID_ARGUMENT: Provided staffUid has an invalid format.');
    }
    if (KNOWN_DEMO_USER_IDS.has(input.staffUid)) {
      throw new Error(
        `INVALID_ARGUMENT: Provided staffUid "${input.staffUid}" is a reserved demo identifier.`
      );
    }
    if (input.staffUid === verifiedAuth.uid) {
      throw new Error(
        'PERMISSION_DENIED: Caller cannot overwrite their own user profile via staff invitation.'
      );
    }
  }

  // Optional Firebase Auth directory cross-check when available to prevent UID/email hijacking
  let authUserForEmail: { uid: string; email: string; emailVerified?: boolean } | null = null;
  if (authDirectory) {
    if (input.staffUid !== undefined) {
      const authByUid = await authDirectory.getUserByUid(input.staffUid);
      if (authByUid && authByUid.email.trim().toLowerCase() !== cleanEmail) {
        throw new Error(
          `PERMISSION_DENIED: Provided staffUid "${input.staffUid}" belongs to a different Firebase Authentication account and cannot be overwritten.`
        );
      }
    }
    authUserForEmail = await authDirectory.getUserByEmail(cleanEmail);
    if (
      authUserForEmail &&
      input.staffUid !== undefined &&
      authUserForEmail.uid !== input.staffUid
    ) {
      throw new Error(
        `PERMISSION_DENIED: Staff email "${cleanEmail}" is registered in Firebase Authentication with UID "${authUserForEmail.uid}", which does not match provided staffUid "${input.staffUid}".`
      );
    }
  }

  return await dbDriver.runTransaction(async (tx) => {
    const caller = await tx.getDoc(`users/${verifiedAuth.uid}`);
    if (!caller || caller.status !== 'active') {
      throw new Error('PERMISSION_DENIED: Active caller profile required.');
    }

    const isAuthorizedOwner =
      caller.role === 'business_owner' && caller.businessId === input.businessId;
    const isAuthorizedAdmin = caller.role === 'platform_admin';

    if (isAuthorizedAdmin) {
      await assertCallerIsActivePlatformAdmin(tx, verifiedAuth);
    }

    if (!isAuthorizedOwner && !isAuthorizedAdmin) {
      throw new Error(
        'PERMISSION_DENIED: Only the Business Owner of this business or a Platform Administrator can provision staff.'
      );
    }

    const businessDoc = await tx.getDoc(`businesses/${input.businessId}`);
    if (!businessDoc || businessDoc.status !== 'active') {
      throw new Error(
        `PERMISSION_DENIED: Business "${input.businessId}" does not exist or is suspended.`
      );
    }

    // Check idempotency ledger first so legitimate retries return the original record
    // while rejecting any attempt to reuse an idempotencyKey with different parameters.
    const staffKeyPath = `businesses/${input.businessId}/staff_provisioning_keys/${input.idempotencyKey}`;
    const existingStaffKey = await tx.getDoc(staffKeyPath);
    if (existingStaffKey) {
      const sameBusiness = existingStaffKey.businessId === input.businessId;
      const sameEmail =
        String(existingStaffKey.staffEmail || '').trim().toLowerCase() === cleanEmail;
      const sameRole = existingStaffKey.role === input.role;
      const sameUid =
        input.staffUid === undefined || existingStaffKey.staffUid === input.staffUid;

      if (!sameBusiness || !sameEmail || !sameRole || !sameUid) {
        throw new Error(
          `ALREADY_EXISTS: Idempotency key "${input.idempotencyKey}" was already used for a different staff provisioning request and cannot be reused with modified parameters.`
        );
      }

      const existingStaffUser = await tx.getDoc(
        `users/${existingStaffKey.staffUid}`
      );
      if (existingStaffUser) {
        return {
          status: 'created',
          isIdempotentReplay: true,
          staffUser: existingStaffUser,
        };
      }
      throw new Error(
        `ALREADY_EXISTS: Idempotency key "${input.idempotencyKey}" has already been consumed.`
      );
    }

    for (const shopId of dedupedAssignedShopIds) {
      const shopDoc = await tx.getDoc(
        `businesses/${input.businessId}/shops/${shopId}`
      );
      if (!shopDoc || shopDoc.businessId !== input.businessId) {
        throw new Error(
          `PERMISSION_DENIED: Shop "${shopId}" does not belong to business "${input.businessId}".`
        );
      }
    }

    const resolvedAuthUid =
      authUserForEmail && isValidEntityId(authUserForEmail.uid)
        ? authUserForEmail.uid
        : undefined;

    const staffUid =
      input.staffUid && isValidEntityId(input.staffUid)
        ? input.staffUid
        : resolvedAuthUid ||
          `usr-staff-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    if (staffUid === verifiedAuth.uid || KNOWN_DEMO_USER_IDS.has(staffUid)) {
      throw new Error(
        'PERMISSION_DENIED: Caller cannot overwrite their own or a reserved user profile via staff invitation.'
      );
    }

    // SEC-09: Prevent overwriting any existing user profile by UID
    const existingUserById = await tx.getDoc(`users/${staffUid}`);
    if (existingUserById) {
      if (existingUserById.businessId !== input.businessId) {
        throw new Error(
          `PERMISSION_DENIED: Target UID "${staffUid}" belongs to another tenant and cannot be overwritten.`
        );
      }
      if (
        existingUserById.role === 'platform_admin' ||
        existingUserById.role === 'business_owner'
      ) {
        throw new Error(
          `PERMISSION_DENIED: Target UID "${staffUid}" belongs to a privileged account (${existingUserById.role}) and cannot be overwritten.`
        );
      }
      throw new Error(
        `ALREADY_EXISTS: Staff user profile "${staffUid}" already exists in business "${input.businessId}" and cannot be overwritten.`
      );
    }

    // SEC-09: Prevent duplicate email or cross-tenant account hijacking by email
    const existingUsersByEmail = await tx.queryDocsByField(
      'users',
      'email',
      cleanEmail
    );
    if (existingUsersByEmail.length > 0) {
      const existingByEmail = existingUsersByEmail[0];
      if (existingByEmail.role === 'platform_admin') {
        throw new Error(
          'PERMISSION_DENIED: Cannot invite a Platform Administrator account as tenant staff.'
        );
      }
      throw new Error(
        `ALREADY_EXISTS: Email "${cleanEmail}" is already registered to user "${existingByEmail.id}" in business "${existingByEmail.businessId}".`
      );
    }

    const nowIso = new Date().toISOString();

    const cleanRoleLabel =
      typeof input.roleLabel === 'string' && input.roleLabel.trim().length > 0
        ? input.roleLabel.trim().slice(0, 100)
        : input.role === 'shop_manager'
        ? 'Shop Manager'
        : 'Cashier';

    const staffDoc: Record<string, any> = {
      id: staffUid,
      businessId: input.businessId,
      username: cleanEmail.split('@')[0].slice(0, 80) || staffUid,
      email: cleanEmail,
      fullName: cleanFullName,
      role: input.role,
      roleLabel: cleanRoleLabel,
      assignedShopIds: dedupedAssignedShopIds,
      permissions: validatedPermissions,
      status: 'active',
      schemaVersion: 6,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    tx.setDoc(`users/${staffUid}`, staffDoc);
    tx.setDoc(staffKeyPath, {
      id: input.idempotencyKey,
      businessId: input.businessId,
      staffUid,
      staffEmail: cleanEmail,
      role: input.role,
      invitedByUid: verifiedAuth.uid,
      schemaVersion: 6,
      createdAt: nowIso,
    });

    const auditId = `aud-staff-${input.idempotencyKey}`;
    tx.setDoc(`businesses/${input.businessId}/audit_events/${auditId}`, {
      id: auditId,
      businessId: input.businessId,
      shopId: dedupedAssignedShopIds[0],
      userId: verifiedAuth.uid,
      userName: String(caller.fullName || 'Business Owner').slice(0, 120),
      action: 'staff_invited',
      entityType: 'user',
      entityId: staffUid,
      detailsJson: JSON.stringify({
        staffUid,
        email: cleanEmail,
        role: input.role,
        assignedShopIds: dedupedAssignedShopIds,
        permissions: validatedPermissions,
        idempotencyKey: input.idempotencyKey,
      }),
      createdAt: nowIso,
    });

    return { status: 'created', isIdempotentReplay: false, staffUser: staffDoc };
  });
}

export async function executeSetTenantStatus(
  dbDriver: ServerDatabaseDriver,
  auth: CallableAuthContext | null | undefined,
  input: SetTenantStatusRequest
): Promise<{
  businessId: string;
  status: 'active' | 'suspended';
  updatedAt: string;
  auditEventId: string;
  subscriptionEventId: string;
}> {
  if (dbDriver.databaseId !== NAMED_FIRESTORE_DATABASE_ID) {
    throw new Error(
      `DATABASE_CONFIG_MISMATCH: Expected named Firestore database "${NAMED_FIRESTORE_DATABASE_ID}", but driver is bound to "${dbDriver.databaseId}".`
    );
  }

  const verifiedAuth = assertVerifiedAuthContext(auth);

  if (
    !input ||
    typeof input !== 'object' ||
    typeof input.businessId !== 'string' ||
    !isValidEntityId(input.businessId) ||
    VALID_PLATFORM_ADMIN_SENTINELS.has(input.businessId) ||
    KNOWN_DEMO_BUSINESS_IDS.has(input.businessId) ||
    input.businessId === PRE_FIREBASE_TEST_BUSINESS_ID ||
    PRE_FIREBASE_BIZ_REGEX.test(input.businessId)
  ) {
    throw new Error(
      `INVALID_ARGUMENT: Business ID "${String((input as any)?.businessId ?? '')}" is invalid, reserved, or quarantined.`
    );
  }

  const requestedStatus: unknown = (input as { status?: unknown }).status;
  if (
    typeof requestedStatus !== 'string' ||
    (requestedStatus !== 'active' && requestedStatus !== 'suspended')
  ) {
    throw new Error(
      `INVALID_ARGUMENT: Tenant status must be "active" or "suspended", received "${String(requestedStatus)}".`
    );
  }
  const validatedStatus: 'active' | 'suspended' = requestedStatus;

  if (input.reason !== undefined && typeof input.reason !== 'string') {
    throw new Error('INVALID_ARGUMENT: Optional reason must be a string.');
  }
  const cleanReason =
    input.reason !== undefined ? input.reason.trim().slice(0, 400) : '';

  return await dbDriver.runTransaction(async (tx) => {
    const callerAdmin = await assertCallerIsActivePlatformAdmin(tx, verifiedAuth);
    const bizPath = `businesses/${input.businessId}`;
    const existingBiz = await tx.getDoc(bizPath);
    if (!existingBiz) {
      throw new Error(`NOT_FOUND: Business "${input.businessId}" does not exist.`);
    }

    const nowIso = new Date().toISOString();
    const previousStatus = String(existingBiz.status || 'active');
    const eventSuffix = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const subscriptionEventId = `sub-evt-${input.businessId}-${eventSuffix}`;
    const auditEventId = `aud-status-${input.businessId}-${eventSuffix}`;

    tx.setDoc(bizPath, {
      ...existingBiz,
      status: validatedStatus,
      updatedAt: nowIso,
    });

    tx.setDoc(
      `businesses/${input.businessId}/subscription_events/${subscriptionEventId}`,
      {
        id: subscriptionEventId,
        businessId: input.businessId,
        previousStatus,
        newStatus: validatedStatus,
        reason: cleanReason || `Tenant status changed to ${validatedStatus}`,
        performedByUid: verifiedAuth.uid,
        performedByEmail: String(callerAdmin.email || BOOTSTRAP_PLATFORM_ADMIN_EMAIL),
        schemaVersion: 6,
        createdAt: nowIso,
      }
    );

    tx.setDoc(`businesses/${input.businessId}/audit_events/${auditEventId}`, {
      id: auditIdFromEvent(auditEventId),
      businessId: input.businessId,
      userId: verifiedAuth.uid,
      userName: String(callerAdmin.fullName || 'Platform Administrator').slice(0, 120),
      action: 'tenant_status_updated',
      entityType: 'business',
      entityId: input.businessId,
      detailsJson: JSON.stringify({
        businessId: input.businessId,
        previousStatus,
        newStatus: validatedStatus,
        reason: cleanReason || undefined,
        subscriptionEventId,
      }),
      createdAt: nowIso,
    });

    return {
      businessId: input.businessId,
      status: validatedStatus,
      updatedAt: nowIso,
      auditEventId,
      subscriptionEventId,
    };
  });
}

function auditIdFromEvent(auditEventId: string): string {
  return auditEventId;
}

// ============================================================================
// 4. FIREBASE ADMIN SDK & CLOUD FUNCTIONS v2 RUNTIME BINDING
// ============================================================================

function loadServerModule(moduleName: string): any {
  return require(moduleName);
}

function createFirebaseAdminDrivers(): {
  dbDriver: ServerDatabaseDriver;
  authDirectory: ServerAuthDirectory;
} {
  // Dynamically require firebase-admin so unit tests can import this module without requiring GCP credentials
  const adminAppModule = loadServerModule('firebase-admin/app');
  const adminFirestoreModule = loadServerModule('firebase-admin/firestore');
  const adminAuthModule = loadServerModule('firebase-admin/auth');

  
  // SECURITY: Verify the actual Firebase runtime project before initializing Admin SDK.
  const runtimeProjectId =
    process.env.GCLOUD_PROJECT ||
    process.env.GCP_PROJECT;

  if (!runtimeProjectId) {
    throw new Error(
      'FIREBASE_PROJECT_ID_UNAVAILABLE: Cannot establish the actual Firebase runtime project.'
    );
  }

  if (runtimeProjectId !== EXPECTED_FIREBASE_PROJECT_ID) {
    throw new Error(
      `FIREBASE_PROJECT_MISMATCH: Expected "${EXPECTED_FIREBASE_PROJECT_ID}", but runtime is "${runtimeProjectId}".`
    );
  }

  // Initialize Admin SDK explicitly for the verified project.
  const app =
    adminAppModule.getApps().length > 0
      ? adminAppModule.getApp()
      : adminAppModule.initializeApp({
          projectId: runtimeProjectId,
        });

  // Verify that the initialized Admin app agrees with the runtime project.
  if (app.options.projectId !== runtimeProjectId) {
    throw new Error(
      `FIREBASE_ADMIN_APP_PROJECT_MISMATCH: Runtime is "${runtimeProjectId}", but Admin SDK app is configured for "${app.options.projectId || 'unknown'}".`
    );
  }

  // Bind Firestore explicitly to the configured database.
  const firestore = adminFirestoreModule.getFirestore(
    app,
    NAMED_FIRESTORE_DATABASE_ID
  );

  const adminAuth = adminAuthModule.getAuth(app);


  const dbDriver: ServerDatabaseDriver = {
    databaseId: NAMED_FIRESTORE_DATABASE_ID,
    async runTransaction<T>(
      updateFunction: (tx: ServerTransactionContext) => Promise<T>
    ): Promise<T> {
      return await firestore.runTransaction(async (nativeTx: any) => {
        const stagedWrites: Array<{ path: string; data: Record<string, any> }> = [];
        const txContext: ServerTransactionContext = {
          async getDoc(path: string) {
            const ref = firestore.doc(path);
            const snap = await nativeTx.get(ref);
            return snap.exists ? (snap.data() as Record<string, any>) : null;
          },
          async queryDocsByField(
            collectionPath: string,
            field: string,
            value: string
          ) {
            const q = firestore
              .collection(collectionPath)
              .where(field, '==', value)
              .limit(5);
            const snap = await nativeTx.get(q);
            return snap.docs.map((d: any) => d.data() as Record<string, any>);
          },
          setDoc(path: string, data: Record<string, any>) {
            stagedWrites.push({ path, data });
          },
        };

        const result = await updateFunction(txContext);
        for (const w of stagedWrites) {
          nativeTx.set(firestore.doc(w.path), w.data, { merge: false });
        }
        return result;
      });
    },
  };

  const authDirectory: ServerAuthDirectory = {
    async getUserByEmail(email: string) {
      try {
        const userRecord = await adminAuth.getUserByEmail(email);
        return {
          uid: userRecord.uid,
          email: userRecord.email || email,
          emailVerified: userRecord.emailVerified,
        };
      } catch (err: any) {
        if (err?.code === 'auth/user-not-found') {
          return null;
        }
        throw err;
      }
    },
    async getUserByUid(uid: string) {
      try {
        const userRecord = await adminAuth.getUser(uid);
        return {
          uid: userRecord.uid,
          email: userRecord.email || '',
          emailVerified: userRecord.emailVerified,
        };
      } catch (err: any) {
        if (err?.code === 'auth/user-not-found') {
          return null;
        }
        throw err;
      }
    },
  };

  return { dbDriver, authDirectory };
}

function wrapCallable<Req, Res>(
  handler: (
    drivers: { dbDriver: ServerDatabaseDriver; authDirectory: ServerAuthDirectory },
    auth: CallableAuthContext | undefined,
    data: Req
  ) => Promise<Res>
) {
  try {
    const httpsV2 = loadServerModule('firebase-functions/v2/https');
    return httpsV2.onCall(
      {
        region: 'us-central1',
        cors: true,
        enforceAppCheck: false,
      },
      async (request: { auth?: CallableAuthContext; data: Req }) => {
        try {
          const drivers = createFirebaseAdminDrivers();
          return await handler(drivers, request.auth, request.data);
        } catch (err: any) {
          const msg = err instanceof Error ? err.message : String(err);
          if (msg.startsWith('UNAUTHENTICATED:')) {
            throw new httpsV2.HttpsError('unauthenticated', msg);
          }
          if (msg.startsWith('PERMISSION_DENIED:') || msg.startsWith('FORBIDDEN')) {
            throw new httpsV2.HttpsError('permission-denied', msg);
          }
          if (msg.startsWith('ALREADY_EXISTS:')) {
            throw new httpsV2.HttpsError('already-exists', msg);
          }
          if (msg.startsWith('NOT_FOUND:')) {
            throw new httpsV2.HttpsError('not-found', msg);
          }
          if (msg.startsWith('INVALID_ARGUMENT:')) {
            throw new httpsV2.HttpsError('invalid-argument', msg);
          }
          throw new httpsV2.HttpsError('internal', msg);
        }
      }
    );
  } catch {
    // Fallback wrapper when imported in pure unit-test environments without firebase-functions installed
    return async (request: { auth?: CallableAuthContext; data: Req }) => {
      const drivers = createFirebaseAdminDrivers();
      return await handler(drivers, request.auth, request.data);
    };
  }
}

export const provisionBusinessAndPrimaryOwner = wrapCallable<
  ProvisionBusinessRequest,
  ProvisionBusinessResponse
>((drivers, auth, data) =>
  executeProvisionBusinessAndPrimaryOwner(
    drivers.dbDriver,
    drivers.authDirectory,
    auth,
    data
  )
);

export const syncPosOperation = wrapCallable<
  SyncOperationPayload,
  SyncOperationResponse
>((drivers, auth, data) => executeSyncPosOperation(drivers.dbDriver, auth, data));

/** Alias exported for backward compatibility with callers using syncShopOperation */
export const syncShopOperation = syncPosOperation;

export const inviteAuthorizedStaff = wrapCallable<
  InviteAuthorizedStaffRequest,
  { status: 'created'; isIdempotentReplay?: boolean; staffUser: Record<string, any> }
>((drivers, auth, data) =>
  executeInviteAuthorizedStaff(
    drivers.dbDriver,
    auth,
    data,
    drivers.authDirectory
  )
);

export const setTenantStatus = wrapCallable<
  SetTenantStatusRequest,
  {
    businessId: string;
    status: 'active' | 'suspended';
    updatedAt: string;
    auditEventId: string;
    subscriptionEventId: string;
  }
>((drivers, auth, data) => executeSetTenantStatus(drivers.dbDriver, auth, data));

export const CLOUD_FUNCTIONS_MANIFEST = {
  runtime: 'nodejs22',
  projectId: EXPECTED_FIREBASE_PROJECT_ID,
  firestoreDatabaseId: NAMED_FIRESTORE_DATABASE_ID,
  requiresBlazePlan: true,
  endpoints: [
    'provisionBusinessAndPrimaryOwner',
    'syncPosOperation',
    'syncShopOperation',
    'inviteAuthorizedStaff',
    'setTenantStatus',
  ],
} as const;
