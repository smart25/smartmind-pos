﻿import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

const currentDir = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig(({ mode }) => {
  const isElectronBuild = mode === 'electron';

  return {
    base: isElectronBuild ? './' : '/',

    plugins: [
      react(),
      tailwindcss(),

      ...(isElectronBuild
        ? []
        : [
            VitePWA({
              registerType: 'prompt',
              includeAssets: [
                'icons/smartmind-pos-192.png',
                'icons/smartmind-pos-512.png',
              ],
              manifest: {
                id: '/',
                name: 'SmartMind POS',
                short_name: 'SmartMind POS',
                description: 'SmartMind POS — multi-shop point of sale and inventory management.',
                start_url: '/',
                scope: '/',
                display: 'standalone',
                background_color: '#f8fafc',
                theme_color: '#064e3b',
                icons: [
                  {
                    src: '/icons/smartmind-pos-192.png',
                    sizes: '192x192',
                    type: 'image/png',
                    purpose: 'any',
                  },
                  {
                    src: '/icons/smartmind-pos-512.png',
                    sizes: '512x512',
                    type: 'image/png',
                    purpose: 'any',
                  },
                ],
              },
              workbox: {
                navigateFallback: '/index.html',
                globPatterns: ['**/*.{html,js,css,svg,png,ico,woff2}'],
                maximumFileSizeToCacheInBytes: 3 * 1024 * 1024,
                globIgnores: ['**/INV-*.pdf', '**/report_*.pdf'],
                cleanupOutdatedCaches: true,
                clientsClaim: false,
                skipWaiting: false,
                runtimeCaching: [],
              },
              devOptions: {
                enabled: false,
              },
            }),
          ]),
    ],

    resolve: {
      alias: {
        '@': currentDir,
      },
    },

    ...(isElectronBuild
      ? {
          build: {
            rolldownOptions: {
              input: {
                index: path.resolve(currentDir, 'index.desktop.html'),
              },
            },
          },
        }
      : {}),

    server: {
      port: 3000,
      host: '0.0.0.0',
    },
  };
});
